import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,Subject } from 'rxjs';
import { ApiResponse } from '../types/common'; 
import { environment } from '../../environments/environment';

export interface TryPromptData {
  agent: any;
  query: any;
}

@Injectable({
  providedIn: 'root'
})
export class PromptRepositoryService {
  constructor(private http: HttpClient) { }

  private tryPromptSource = new Subject<TryPromptData>();
  tryPrompt$ = this.tryPromptSource.asObservable();

  triggerTryPrompt(data: TryPromptData) {
    this.tryPromptSource.next(data);
  }

  getAgencyWithAgentsEnhanced(): Observable<ApiResponse<any>> {
    return this.http.get<ApiResponse<any>>(`/GetAgencyWithAgentsEnhanced`);
  }
  
  savePrompt(params: any) {
    return this.http.post<ApiResponse<any>>(`/SavePrompt`, params);
  }
  
  UpdatePrompt(params: any) {
    return this.http.post<ApiResponse<any>>(`/UpdatePrompt`, params);
  }

  batchUpdatePrompts(params: any) {
    return this.http.post<ApiResponse<any>>(`/BatchUpdate`, params);
  }

  DeletePrompt(params: any) {
    return this.http.post<ApiResponse<any>>(`/DeletePrompt`, params);
  }

}