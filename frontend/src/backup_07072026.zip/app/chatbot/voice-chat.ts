import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  AfterViewInit,
  inject,
  effect,
  ViewEncapsulation,
  computed,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { VoiceAgentService, VoiceState } from '../services/voice-agent.service';
import { environment } from '../../environments/environment';
import { Header } from '../header/header';
import { rxResource } from '@angular/core/rxjs-interop';
import { SemarketplaceService } from '../services/semarketplace.service';
import { TOption, Select } from '../components/select/select';

interface LogEvent {
  time: string;
  text: string;
  type: 'final' | 'warn' | 'err' | 'info';
}

@Component({
  selector: 'voice-chatbot',
  standalone: true,
  imports: [CommonModule, FormsModule, Header, Select],
  encapsulation: ViewEncapsulation.None,
  template: `
    <app-header></app-header>

    <div class="root">
      <div class="bg-white px-2 border-bottom pb-1">
        <div class="d-flex align-items-center gap-3 justify-content-between">
          <div class="controls fs-14 d-flex gap-3 align-items-center">
            <div class="controls-row">
              @let aOptions = agentOptions();
              <span class="text-muted fw-semibold">Mova-iO Agent</span>
              <app-select
                placeholder="Select"
                [options]="aOptions"
                [(ngModel)]="activeAgentId"
                [allowSearch]="false"
                (onSelect)="eventLog.set([])"
                style="
        --min-height: auto;
        --width: 16rem;
        --option-font-size: 0.9rem;
        --font-size: 0.7rem;
      "
                [parentWidth]="false"
                [disabled]="
                  voice.connected() ||
                  voiceAgentsQuery.isLoading() ||
                  !aOptions.length
                "
              />
            </div>

            <div class="controls-row">
              <button
                class="primary btn btn-sm rounded-4 px-3"
                [class.live]="voice.connected()"
                [disabled]="voice.connecting() || voiceAgentsQuery.isLoading()"
                (click)="toggleCall()"
              >
                @if (voice.connected()) {
                  <i class="fa-solid fa-stop"></i> End call
                } @else {
                  <i class="fa-solid fa-microphone"></i> Start call
                }
              </button>

              <button
                *ngIf="voice.connected() && voice.micPermission() === 'denied'"
                (click)="retryMic()"
              >
                🎤 Enable mic
              </button>
            </div>
          </div>

          <div class="d-flex fs-12 align-items-center gap-3 text-capitalize">
            <div class="d-flex gap-1  align-items-center ">
              <span class="fw-semibold">Status:</span>
              <span class="dot" [ngClass]="statusColorClass"></span>
              <span class="text-muted">{{ statusText }}</span>
              <div style="flex:1"></div>
            </div>

            <div class="d-flex gap-1  align-items-center ">
              <span class="text-muted fw-semibold">mic</span>
              <div class="meter" title="mic input level">
                <div class="bar" [style.width.%]="voice.micLevel()"></div>
              </div>
            </div>
          </div>
        </div>

        <div class="px-2 fs-14 text-muted">{{ getHintText() }}</div>
        @if (voice.error()) {
          <div class="fs-14 text-danger text-center" *ngIf="">
            {{ voice.error() }}
          </div>
        }
      </div>

      <div class="chat-area" style="min-height: 0;">
        <section class="panel">
          <h2>This turn</h2>
          <div class="row">
            <span class="k fw-semibold">You said</span>
            <span class="v"
              ><span
                class="badge"
                *ngIf="!voice.interimUserText() && latestUser"
                >you</span
              ></span
            >
          </div>
          <div
            class="transcript"
            [class.thinking]="voice.state() === 'THINKING'"
          >
            <span *ngIf="voice.interimUserText()">{{
              voice.interimUserText()
            }}</span>
            <span *ngIf="!voice.interimUserText() && latestUser">{{
              latestUser
            }}</span>
            <span class="muted" *ngIf="!voice.interimUserText() && !latestUser">
              {{
                voice.connected()
                  ? 'listening...'
                  : 'click Start call and start talking…'
              }}
            </span>
          </div>

          <hr
            style="border:0; border-top:1px solid var(--border); margin:14px 0;"
          />

          <div class="row">
            <span class="k fw-semibold">Agent answer</span>
            <span class="v"
              ><span class="badge" *ngIf="voice.state() === 'THINKING'"
                >Thinking...</span
              ></span
            >
          </div>
          <div
            class="answer"
            [class.thinking]="
              voice.state() === 'SPEAKING' &&
              !voice.interimAgentText() &&
              !latestAgent
            "
          >
            <span *ngIf="voice.interimAgentText()">{{
              voice.interimAgentText()
            }}</span>
            <span *ngIf="!voice.interimAgentText() && latestAgent">{{
              latestAgent
            }}</span>
            <span
              class="muted"
              *ngIf="!voice.interimAgentText() && !latestAgent"
              >—</span
            >
          </div>
        </section>

        <div
          style="display: grid; grid-template-rows: 1fr auto; gap: 0.5rem; min-height: 0;"
        >
          <section class="panel d-flex flex-column" style="min-height: 0;">
            <div class="d-flex align-items-center justify-content-between">
              <h2>Event stream (raw)</h2>
              <button
                type="button"
                class="btn btn-sm btn-warning text-white"
                (click)="eventLog.set([])"
              >
                Clear
              </button>
            </div>
            <div class="events" #eventsContainer>
              @for (ev of eventLog(); track ev.time) {
                <div class="e" [ngClass]="ev.type">
                  {{ ev.time }} &nbsp;&nbsp; {{ ev.text }}
                </div>
              }
            </div>
          </section>

          <section class="panel">
            <h2>Live activity (last 60 sec)</h2>
            <canvas
              #monitorCanvas
              style="width:100%;height:80px;display:block;background:var(--surface);border-radius:6px;"
            ></canvas>
            <div class="chart-legend" style="margin-top:6px;">
              <span class="lg"
                ><span class="sw" style="background:var(--c1);"></span> Mic
                input</span
              >
              <span class="lg"
                ><span class="sw" style="background:var(--c4);"></span> Agent
                output</span
              >
              <span
                style="margin-left:auto;color:var(--muted);font-family:var(--mono);font-variant-numeric:tabular-nums;"
              >
                {{ voice.metrics().sessionDuration }}s
              </span>
            </div>
          </section>
        </div>
      </div>
    </div>
  `,
  styles: `
    :root {
      --panel: #ffffff;
      --muted: #5a6478;
      --soft: #3a4256;
      --text: #0e1320;
      --accent: #f9a84a;
      --ok: #1c8f3c;
      --warn: #b56a06;
      --err: #c43030;
      --c1: #f9a84a;
      --c2: #1c8f3c;
      --c3: #1f6dd1;
      --c4: #7a3ec0;
      --c5: #c43030;
      --surface: #eef1f6;
      --surface-2: #e2e7ef;
      --border: #cdd4de;
      --grid: #dfe4ec;
      --gate-bg: rgba(247, 249, 252, 0.92);
    }

    .root {
      height: calc(100% - 5rem);
      margin-top: 4.063rem;
      display: grid;
      grid-template-rows: auto 1fr;
    }

    .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--muted);
      transition: background 0.3s;
    }
    .dot.ok {
      background: var(--ok);
    }
    .dot.warn {
      background: var(--warn);
    }
    .dot.err {
      background: var(--err);
    }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 6px;
      background: var(--surface);
      font-size: 12px;
      color: var(--accent);
      cursor: pointer;
      border: 0;
    }
    .meter {
      width: 160px;
      height: 8px;
      background: var(--surface-2);
      border-radius: 4px;
      overflow: hidden;
    }
    .meter > .bar {
      height: 100%;
      background: linear-gradient(
        90deg,
        var(--ok) 0%,
        var(--warn) 70%,
        var(--err) 100%
      );
      transition: width 60ms linear;
    }
    .controls {
      padding: 0.5rem;
    }
    .controls-row {
      display: flex;
      gap: 12px;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
    }
    button:hover {
      background: var(--surface-2);
    }
    button:disabled {
      opacity: 0.4;
      cursor: not-allowed;
    }
    button.primary {
      background: #f9a84a;
      color: white;
    }
    button.primary.live {
      background: var(--err);
    }
    .chat-area {
      display: grid;
      grid-template-columns: 340px 1fr;
      gap: 0.5rem;
      width: 100%;
      padding: 0.5rem;
    }
    .panel {
      background: var(--panel);
      border-radius: 10px;
      padding: 14px 16px;
      border: 1px solid #e1e0e38d;
    }
    .panel h2 {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      color: var(--muted);
      margin: 0 0 10px;
    }
    .row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 4px 0;
      font-size: 13px;
    }
    .row .k {
      color: var(--muted);
    }
    .transcript,
    .answer {
      font-size: 15px;
      line-height: 1.5;
      min-height: 48px;
      white-space: pre-wrap;
    }
    .muted {
      color: var(--muted);
      font-style: italic;
    }
    .thinking {
      color: var(--accent);
      animation: thinking-pulse 1.2s ease-in-out infinite;
    }
    @keyframes thinking-pulse {
      0%,
      100% {
        opacity: 0.55;
      }
      50% {
        opacity: 1;
      }
    }
    .chart-legend {
      display: flex;
      gap: 0.8rem;
      font-size: 11px;
      color: var(--soft);
    }
    .chart-legend .sw {
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 2px;
    }
    .events {
      font-family: var(--mono);
      font-size: 0.875rem;
      line-height: 1.75;
      overflow: auto;
      color: var(--soft);
      min-height: 0;
      height: 100%;
    }
    .events .e.err {
      color: var(--err);
    }
    .events .e.final {
      color: var(--text);
    }
    .events .e.warn {
      color: var(--warn);
    }
    input,
    select {
      background: var(--surface);
      color: var(--text);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 6px 10px;
    }
  `,
})
export class VoiceChat implements OnInit, AfterViewInit, OnDestroy {
  voice = inject(VoiceAgentService);
  service = inject(SemarketplaceService);

  @ViewChild('monitorCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('eventsContainer') eventsContainer!: ElementRef<HTMLDivElement>;

  showGate = true;
  theme: 'light' | 'dark' = 'dark';

  activeAgentId = signal('');

  latestUser = '';
  latestAgent = '';

  eventLog = signal<LogEvent[]>([]);
  private msgSub!: Subscription;

  private rafId: number | null = null;
  private readonly MON_SAMPLES = 60 * 30;
  private monMic = new Float32Array(this.MON_SAMPLES);
  private monAgent = new Float32Array(this.MON_SAMPLES);
  private monIdx = 0;

  agentOptions = computed<TOption[]>(() => {
    if (this.voiceAgentsQuery.error()) return [];

    const agents = this.voiceAgentsQuery.value()?.agents || [];
    return agents.map((item) => ({
      label: item.config.agent_name,
      value: item.id,
    }));
  });

  constructor() {
    effect(() => {
      const state = this.voice.state();
      this.log(`State transition: ${state}`, 'info');

      if (state === VoiceState.LISTENING) {
        this.latestUser = '';
        this.latestAgent = '';
      }
    });

    effect(() => {
      const err = this.voice.error();
      if (err) this.log(`Error: ${err}`, 'err');
    });

    effect(() => {
      const voiceAgent = this.agentOptions()?.[0];
      if (!voiceAgent) return;

      this.voice.initialize({
        agentId: voiceAgent.value,
        startSessionUrl: `${environment.apiUrl}/voice-agent/sessions/start`,
        endSessionUrl: `${environment.apiUrl}/voice-agent/sessions/end`,
        autoReconnect: true,
        debug: true,
      });
    });
  }

  ngOnInit() {
    this.msgSub = this.voice.messages$.subscribe((msg) => {
      if (msg.role === 'user') {
        this.latestUser = msg.text;
        this.log(`you: ${msg.text}`, 'final');
      } else {
        this.latestAgent = msg.text;
        this.log(`agent: ${msg.text}`, 'final');
      }
    });
  }

  ngAfterViewInit() {
    this.startCanvasMonitor();
  }

  ngOnDestroy() {
    if (this.rafId) cancelAnimationFrame(this.rafId);
    if (this.msgSub) this.msgSub.unsubscribe();
    this.voice.stop();
  }

  unlockAndStart() {
    this.voice.unlockAudio();
    this.showGate = false;
    this.log('Audio unlocked', 'info');
  }

  toggleCall() {
    if (this.voice.connected() || this.voice.connecting()) {
      this.voice.stop();
      this.log('Call ended', 'info');
    } else {
      const activeAgentId = this.activeAgentId();

      this.voice.switchAgent(activeAgentId);
      this.voice.start();
      this.log(`Starting call with agent: ${activeAgentId}`, 'warn');
    }
  }

  retryMic() {
    this.voice.unmute();
  }

  get statusColorClass() {
    const state = this.voice.state();
    if (state === VoiceState.ERROR) return 'err';
    if (state === VoiceState.CONNECTING) return 'warn';
    if (this.voice.connected()) return 'ok';
    return '';
  }

  get statusText() {
    const state = this.voice.state();
    if (state === VoiceState.ERROR) return 'error';
    if (state === VoiceState.CONNECTING) return 'connecting...';
    if (this.voice.connected())
      return this.voice.micPermission() === 'denied' ? 'live (no mic)' : 'live';
    return 'ready';
  }

  get HintText() {
    if (!this.voice.connected())
      return 'Click Start call — the agent greets you, then just talk. Click again to hang up.';
    if (this.voice.micPermission() === 'denied')
      return 'Connected — listening to the agent. Enable your mic to talk back.';
    return 'the agent will greet you — just talk. Click End call to hang up.';
  }

  getHintText() {
    return this.HintText;
  }

  private log(text: string, type: LogEvent['type'] = 'info') {
    const time = new Date().toISOString().slice(11, 23);
    this.eventLog.update((v) => {
      const newLogs = [...v, { time, text, type }];
      if (newLogs.length > 200) newLogs.shift();
      return newLogs;
    });
    setTimeout(() => {
      if (this.eventsContainer) {
        const el = this.eventsContainer.nativeElement;
        el.scrollTop = el.scrollHeight;
      }
    }, 10);
  }

  private startCanvasMonitor() {
    let lastDraw = 0;

    const loop = (timestamp: number) => {
      this.rafId = requestAnimationFrame(loop);

      if (timestamp - lastDraw < 1000 / 30) return;
      lastDraw = timestamp;

      this.monMic[this.monIdx] = this.voice.micLevel() / 100;
      this.monAgent[this.monIdx] = this.voice.agentLevel() / 100;

      this.monIdx = (this.monIdx + 1) % this.MON_SAMPLES;
      this.drawMonitor();
    };

    this.rafId = requestAnimationFrame(loop);
  }

  private drawMonitor() {
    if (!this.canvasRef) return;
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.parentElement!.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    if (
      canvas.width !== Math.round(rect.width * dpr) ||
      canvas.height !== Math.round(140 * dpr)
    ) {
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(140 * dpr);
    }

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, rect.width, 140);

    const cs = getComputedStyle(document.body);
    const colGrid = cs.getPropertyValue('--grid').trim() || '#222a3a';
    const colMic = cs.getPropertyValue('--c1').trim() || '#7ab1ff';
    const colAgent = cs.getPropertyValue('--c4').trim() || '#d186ff';

    ctx.strokeStyle = colGrid;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, 70);
    ctx.lineTo(rect.width, 70);
    ctx.stroke();

    const drawTrace = (
      buf: Float32Array,
      color: string,
      multiplier: number,
    ) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.beginPath();

      for (let i = 0; i < this.MON_SAMPLES; i++) {
        const readIdx = (this.monIdx + i) % this.MON_SAMPLES;
        const x = (i / this.MON_SAMPLES) * rect.width;
        const y = 70 + multiplier * buf[readIdx] * 66;

        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    };

    drawTrace(this.monMic, colMic, -1);
    drawTrace(this.monAgent, colAgent, 1);
  }

  voiceAgentsQuery = rxResource({
    stream: () => this.service.getVoiceAgents(),
  });
}
