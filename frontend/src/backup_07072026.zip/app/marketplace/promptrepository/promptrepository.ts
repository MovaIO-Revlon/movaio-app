import { Component, HostListener, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { PromptRepositoryService, TryPromptData } from '../../services/prompt-repository.service';
import { AIInfuseStateService } from '../../services/aiinfuse-state.service';
import { Router, NavigationEnd } from '@angular/router';
import { TooltipDirective } from '../../custom-tooltip/tooltip.directive';
import { SemarketplaceService } from '../../services/semarketplace.service';

declare var bootstrap: any;

interface Agent {
  agent_id: string;
  agent_type_id: string;
  agent_type_name:string;
  name: string;
  usage_count?: number;
  last_used?: string;
  average_rating?: number;
  queries?: any[];
  description?: string;
  model?: string;
  master_agent_id?: string;
  master_agent_name?: string;
  agency_id:string;
}

interface Agency {
  agency_name: string;
  agency_run_count: number;
  agents: Agent[];
  avatar?: string;
}

interface PromptMetrics {
  correctness?: number;
  accuracy?: number;
  safety?: number;
  coherence?: number;
  conciseness?: number;
  relevance?: number;
  latency?: number;
  status?: number;
  // Add more as needed
}

@Component({
  selector: 'app-promptrepository',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule,TooltipDirective],
  templateUrl: './promptrepository.html',
  styleUrls: ['./promptrepository.css']
})
export class Promptrepository {
  constructor(
    private _loadingService: NgxSpinnerService,
    private promptRepoService: PromptRepositoryService,
    private _stateService: AIInfuseStateService,
    private cdr: ChangeDetectorRef,
    private _router: Router,
    private _marketService: SemarketplaceService,
  ) {}
  
  apiData: any = null;
  selectedAgency: any = null;
  showAddPrompt = false;
  currentAgent: any = null;
  newPRForm = {
    agency: '',
    agent: '',
    promptTitle: '',
    prompt: '',
    created_by: '',
    map_id:''
  };
  promptActions: { [key: string]: boolean } = {};
  filteredAgentsForModal: Agent[] = [];
  toastMessage: string = '';
  toastType: 'success' | 'error' = 'success';
  deleteConfirmModal: any;
  queryToDelete: any = null;
  isDeleting = false;
  agentToDelete: any = null;
  editConfirmModal: any;
  queryToEdit: any = null;
  agentToEdit: any = null;
  isEditing = false;
  editForm = {
    promptTitle: '',
    prompt: ''
  };
  isSuperAdmin: boolean = false;
  globalSearchTerm: string = '';
  modalSearchTerm: string = '';
  filteredAgencies: any[] = [];
  filteredAgentsInModal: Agent[] = [];
  filteredModalData: any[] = [];
  filterAgency: string = '';
  filterAgent: string = '';
  filteredFilterAgents: any[] = [];
  allAvailableAgents: any[] = [];
  editWarningModal: any = null;
  queryToEditWarning: any = null;
  agentToEditWarning: any = null;
  agenciesWithAgents: any[] = [];
  itemsPerPage: number = 10;
  promptPageMap: { [agentId: string]: number } = {};
  isLoadingAgencies: boolean = false;
  expandedAgentId: string | null = null;
  expandedQueryId: string | null = null;
  isPrivilegeView: boolean = false;
  isPrivilegeEdit: boolean = false;
  isPrivilegeDelete: boolean = false;
  isPrivilegeExecute: boolean = false;


  ngOnInit(): void {
    this.loadPrivileges();
    this.fetchAgencies();
    this.fetchAgenciesWithAgents();
    this.filteredAgencies = [];
    const deleteModalEl = document.getElementById('deleteConfirmModal');
    if (deleteModalEl) {
      this.deleteConfirmModal = new bootstrap.Modal(deleteModalEl);
    }
    const editModalEl = document.getElementById('editConfirmModal');
    if (editModalEl) {
      this.editConfirmModal = new bootstrap.Modal(editModalEl);
    }

    const editWarningEl = document.getElementById('editWarningModal');
      if (editWarningEl) {
        this.editWarningModal = new bootstrap.Modal(editWarningEl);
      }
  }

   loadPrivileges() {
    this._stateService.getPrivilegesByPage('Prompt Repository').subscribe({
      next: (loaded_privileges:any) => {
        console.log('Loaded privileges for Prompt Repository by page: ', loaded_privileges);
        if (loaded_privileges) {
          this.isPrivilegeView = loaded_privileges?.view || false;
          this.isPrivilegeEdit = loaded_privileges?.['insert / edit'] || loaded_privileges?.edit || false;
          this.isPrivilegeDelete = loaded_privileges?.delete || false;
          this.isPrivilegeExecute = loaded_privileges?.execute || false;
          this.cdr.detectChanges();
        }
      }
    });
  }

  checkUserRole() {
    const loggedUser = this._stateService.getLoginDetails();
    const activePrj = loggedUser?.ActiveProject;
    const projectDetails = loggedUser?.ProjectDtl || [];

    const mappedProject = projectDetails.find(
      (p: any) => p.prj_name?.toLowerCase() === activePrj?.toLowerCase()
    );

    const mappedRole = mappedProject?.role_name?.toLowerCase() || '';

    this.isSuperAdmin = mappedRole === 'super admin';

    console.log('User Role Check - Super Admin:', this.isSuperAdmin);
  }

    fetchAgenciesWithAgents(): void {
    this._loadingService.show();
    this._marketService.getAgencyWithAgents().subscribe({
      next: (res) => {
        this._loadingService.hide();
        if (res.success && res.data) {
          this.agenciesWithAgents = res.data;
          console.log('Agencies with agents loaded for modal:', this.agenciesWithAgents);
        } else {
          console.warn('No data received from getAgencyWithAgents');
        }
      },
      error: (err) => {
        this._loadingService.hide();
        console.error('Error fetching agencies with agents:', err);
        this.showToast('error', 'Failed to load agencies');
      }
    });
  }

  fetchAgencies() {
  this.isLoadingAgencies = true;
  this.filteredAgencies = [];   
  this.apiData = [];
  this._loadingService.show();

  this.promptRepoService.getAgencyWithAgentsEnhanced().subscribe(
    (response) => {
      this.apiData = response.data || [];
      this.filteredAgencies = [...this.apiData];
      this.prepareFilterData();
     
      setTimeout(() => {
        this.autoFixNoTitlePrompts();
      }, 800);
      

      this.isLoadingAgencies = false;
      this._loadingService.hide();
      this.cdr.detectChanges();
    },
    (error) => {
      console.error('Error fetching agencies:', error);
      this.apiData = [];
      this.filteredAgencies = [];
      this.isLoadingAgencies = false;
      this._loadingService.hide();
      this.cdr.detectChanges();
    }
  );
}
  
    onAgencyChange(selectedAgencyName: string) {
    if (!selectedAgencyName || !this.agenciesWithAgents?.length) {
      this.filteredAgentsForModal = [];
      return;
    }

    const selectedAgency = this.agenciesWithAgents.find((agency: any) => 
      agency.agency_name === selectedAgencyName
    );

    if (selectedAgency) {
      this.filteredAgentsForModal = this.getFilteredAgents(selectedAgency);
    } else {
      this.filteredAgentsForModal = [];
    }
  }

  showToast(type: 'success' | 'error', message: string): void {
  this.toastType = type;
  this.toastMessage = message;
  this.cdr.detectChanges(); // Trigger change detection
  
  // Show toast after DOM update
  setTimeout(() => {
    const toastId = type === 'success' ? '#successToast' : '#errorToast';
    const toastEl = document.querySelector(toastId) as HTMLElement;
    if (toastEl) {
      const toast = new bootstrap.Toast(toastEl, {
        autohide: true,
        delay: 4000
      });
      toast.show();
    }
  }, 0);
}

tryThisPrompt(agent: Agent, query: any) {
  if (!agent || !query) return;

  console.log('tryThisPrompt called with:', { 
    agentId: agent.agent_id, 
    agentName: agent.name,
    queryId: query._id,
    status: query.status,
    executionCount: query.execution_count
  });

  const statusObj = this.getExecutionStatus(query);
  const isReExecute = statusObj.label === 'Re-execute';

  // ==================== PRIVILEGE CHECK ====================
  const hasExecutePrivilege = this.isPrivilegeExecute;
  const hasViewPrivilege = this.isPrivilegeView;

  if (!hasViewPrivilege) {
    this.showToast('error', 'You do not have permission to view this prompt.');
    return;
  }

  // If user has NO execute privilege:
  if (!hasExecutePrivilege) {
    if (isReExecute) {
      // Allow viewing in review mode (do not auto-execute)
      console.log('Re-execute prompt opened in REVIEW mode (view-only user)');
    } else {
      // Block execution for non-re-execute prompts
      this.showToast('error', 'You do not have access to execute this prompt.');
      return;
    }
  }
  // ========================================================

  // Resolve proper Master Agent
  let masterAgent = agent;

  if (agent.agent_type_id === 'TYPE_MASTER' || 
      !agent.agent_type_id?.toLowerCase().includes('master')) {
    
    masterAgent = this.findMasterAgentForTask(agent.agent_id) || agent;
  }

  // ==================== Determine Auto-Execute Logic ====================
  let shouldAutoExecute = false;

  if (isReExecute) {
    // Re-execute behavior depends on privilege
    shouldAutoExecute = hasExecutePrivilege;   // Execute only if user has execute right
  } else {
    // Normal prompts: auto-execute only if never run before
    const hasBeenExecuted = !!(query.execution_count && Number(query.execution_count) > 0) ||
                            !!(query.status && query.status.toLowerCase() === 'completed');
    shouldAutoExecute = !hasBeenExecuted;
  }
  // ===================================================================

  const agencyId = this.selectedAgency?.agency_id ||
                   this.selectedAgency?._id ||
                   query.agency_id || 
                   agent.agency_id || '';

  const eventId = query.event_id || '';
  const mapId = query.map_id || '';

  const payload = {
    agent: {
      ...agent,
      master_agent_id: masterAgent.agent_id || agent.agent_id,
      master_agent_name: masterAgent.name || agent.name,
      name: agent.name,
      agent_id: agent.agent_id,
      agency_id: agencyId,
      agent_type_id: masterAgent.agent_type_id || agent.agent_type_id
    },
    query: {
      ...query,
      user_query: query.user_query || query.promptTitle || query.title,
      prompt_output: query.prompt_output,
      name: agent.name,
      agent_id: agent.agent_id,
      master_agent_id: masterAgent.agent_id || agent.agent_id,
      master_agent_name: masterAgent.name || agent.name,
      agency_id: agencyId,
      event_id: eventId,
      map_id: mapId
    },
    isFromPromptRepository: true,
    shouldAutoExecute: shouldAutoExecute
  };

  console.log('Try Prompt Payload - Auto Execute:', shouldAutoExecute, 
              '| Re-execute:', isReExecute, 
              '| Has Execute Privilege:', hasExecutePrivilege);

  this._stateService.setTryPromptData(payload);
  this._router.navigate(['/commandcenterdashboard']);
}

private findMasterAgentForTask(taskAgentId: string): any {
  if (!taskAgentId || !this.agenciesWithAgents?.length) {
    console.warn('agenciesWithAgents not loaded yet');
    return null;
  }

  for (const agency of this.agenciesWithAgents) {
    // Check if this task agent belongs to the agency
    const isTaskAgentInAgency = agency.agents?.some((a: any) => a.agent_id === taskAgentId);
    
    if (isTaskAgentInAgency) {
      // Find Master Agent in the same agency
      const master = agency.agents?.find((a: any) => 
        a.agent_type_id === 'MASTER' || 
        a.agent_type_name?.toLowerCase().includes('master')
      );

      if (master) {
        console.log(`Resolved Master Agent: ${master.name} (${master.agent_id}) for Task Agent: ${taskAgentId}`);
        return master;
      }
    }
  }

  console.warn(`Could not resolve master agent for: ${taskAgentId}`);
  return null;
}

  openAgencyModal(agency: any) {
  this.selectedAgency = agency;
  this.showAddPrompt = false;
  this.modalSearchTerm = '';
  const filteredAgents = this.getFilteredAgents(agency);
  this.filteredModalData = [...filteredAgents];
  
  // Reset expanded state
  this.expandedAgentId = null;
  this.expandedQueryId = null;
  this.promptPageMap = {};

  setTimeout(() => {
    const modalElement = document.getElementById('agencyModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }, 0);
}
  // Initialize accordions properly
  initializeAccordions(modalElement: HTMLElement) {
    // Get all accordion buttons
    const accordionButtons = modalElement.querySelectorAll('.accordion-button') as NodeListOf<HTMLButtonElement>;
    
    accordionButtons.forEach(button => {
      // Get target collapse element
      const targetId = button.getAttribute('data-bs-target');
      if (targetId) {
        const target = modalElement.querySelector(targetId) as HTMLElement;
        if (target) {
          // Initialize Bootstrap Collapse
          const collapse = new bootstrap.Collapse(target, {
            toggle: false  // Don't auto-open
          });
          
          // Ensure it's collapsed
          collapse.hide();
        }
      }
    });
  }
  
getLastExecutedTime(lastUsed: string | null | undefined, executionCount: number = 0): string {
  // If never executed, always show 'Never' — regardless of created_ts
  if (!executionCount || executionCount <= 0) {
    return 'Never';
  }

  if (!lastUsed) return 'Never';

  try {
    const lastUsedDate = new Date(lastUsed);
    if (isNaN(lastUsedDate.getTime())) return 'Invalid date';

    const now = new Date();
    const diffInMs = now.getTime() - lastUsedDate.getTime();

    if (diffInMs < 0) return 'In the future';

    const minutes = Math.floor(diffInMs / (1000 * 60));
    const hours = Math.floor(diffInMs / (1000 * 60 * 60));
    const days = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    const months = Math.floor(diffInMs / (1000 * 60 * 60 * 24 * 30));

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 30) return `${days}d ago`;
    return `${months}mo ago`;
  } catch (error) {
    console.error('Error parsing date:', error);
    return 'Invalid date';
  }
}

  getLastExecuted(agents: any[]): string {
    if (!agents?.length) return '';
    
    const latestDate = agents.reduce((max, agent) => {
      if (!agent.last_used) return max;
      const date = new Date(agent.last_used);
      return max > date ? max : date;
    }, new Date(0));

    if (latestDate.getTime() === 0) return '';
    
    const now = new Date();
    const diff = now.getTime() - latestDate.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    return hours < 24 ? `${hours}h ago` : `${Math.floor(hours/24)}d ago`;
  }


  cancelAddPrompt() {
    this.showAddPrompt = false;
    // Trigger change detection
    this.cdr.detectChanges();
  }

 toggleActions(event: Event, queryId: string) {
  event.stopImmediatePropagation();

  // Force open the accordion first
  this.expandedQueryId = queryId;

  // Toggle the menu
  this.promptActions[queryId] = !this.promptActions[queryId];

  // Small delay for smooth accordion expansion
  if (this.promptActions[queryId]) {
    setTimeout(() => {
      this.cdr.detectChanges();
    }, 80);
  } else {
    this.cdr.detectChanges();
  }
}

editPrompt(event: Event, query: any, agent: Agent) {
  event.stopImmediatePropagation();

  // === FORCE OPEN THE PROMPT ACCORDION ===
  this.expandedQueryId = query._id;

  // Add editing properties
  query.isEditing = true;
  query.editTitle = query.prompt_title || '';
  query.editPrompt = query.user_query || '';

  // Close action popup
  this.promptActions = {};

  this.cdr.detectChanges();
}

cancelEditQuery(agent: Agent, query: any) {
  // Remove editing properties
  query.isEditing = false;
  delete query.editTitle;
  delete query.editPrompt;
  
  // Trigger change detection
  this.cdr.detectChanges();
}

saveEditedQuery(agent: Agent, query: any) {
  if (!query.editTitle?.trim() || !query.editPrompt?.trim()) {
    this.showToast('error', 'Title and prompt content are required!');
    return;
  }

  const originalPrompt = query.user_query?.trim();
  const newPrompt = query.editPrompt?.trim();
  const isPromptContentChanged = originalPrompt !== newPrompt;

  // Deep copy for warning modal
  this.queryToEditWarning = JSON.parse(JSON.stringify(query));
  this.agentToEditWarning = agent;

  if (isPromptContentChanged && this.editWarningModal) {
    this.editWarningModal.show();
  } else {
    this.proceedWithEditSave(query, agent);
  }
}

private refreshModalDataAfterEdit(agentId: string) {
  if (!this.selectedAgency?.agents) return;

  const agent = this.selectedAgency.agents.find((a: Agent) => a.agent_id === agentId);
  if (!agent) return;

  const indexInModal = this.filteredModalData.findIndex((a: Agent) => a.agent_id === agentId);
  
  if (indexInModal !== -1) {
    this.filteredModalData[indexInModal] = { ...agent, queries: [...(agent.queries || [])] };
  } else {
    this.filteredModalData = this.getFilteredAgents(this.selectedAgency);
  }

  this.cdr.detectChanges();
}

proceedWithEditSave(query?: any, agent?: any) {
  if (!query || !agent) {
    query = this.queryToEditWarning;
    agent = this.agentToEditWarning;
  }

  if (!query || !agent) {
    this.showToast('error', 'Something went wrong.');
    this.editWarningModal?.hide();
    return;
  }

  this.editWarningModal?.hide();
  this._loadingService.show();

  const eventId = query.event_id || '';
  const mapId = query.map_id || this.generateUUID();

  const payload = {
    agency_id: this.selectedAgency?.agency_id || this.selectedAgency?._id || '',
    agent_id: agent.agent_id,
    prompt_title: query.editTitle.trim(),
    user_query: query.editPrompt.trim(),
    event_id: eventId,
    map_id: mapId
  };

  this.promptRepoService.UpdatePrompt(payload).subscribe({
    next: (response) => {
      this._loadingService.hide();

      if (response?.success) {
        this.showToast('success', 'Prompt updated successfully!');

        const originalQuery = this.findOriginalQuery(agent, query);

        if (originalQuery) {
          const oldPrompt = originalQuery.user_query?.trim() || '';
          const newPrompt = query.editPrompt?.trim() || '';

          const isContentChanged = oldPrompt !== newPrompt;

          // Always update title and prompt
          originalQuery.prompt_title = query.editTitle.trim();
          originalQuery.user_query = newPrompt;

          // === Reset metrics/execution data ONLY if content changed ===
          if (isContentChanged) {
            console.log('Prompt content changed → Resetting execution data');
            originalQuery.status = 'stored';           // or 'updated'
            originalQuery.execution_count = 0;
            originalQuery.metrics = null;
            originalQuery.detailed_results = null;
            originalQuery.prompt_output = '';          // optional
            originalQuery.feedback_rating = 0;
            originalQuery.feedback_comments = '';
          }

          originalQuery.isEditing = false;
          delete originalQuery.editTitle;
          delete originalQuery.editPrompt;
        }

        // Refresh modal data immediately
        this.refreshModalDataAfterEdit(agent.agent_id);

        this.cdr.detectChanges();
      } else {
        this.showToast('error', 'Failed to update: ' + (response?.message || ''));
      }
    },
    error: (err) => {
      this._loadingService.hide();
      console.error('Update error:', err);
      this.showToast('error', 'Error updating prompt.');
    }
  });

  this.queryToEditWarning = null;
  this.agentToEditWarning = null;
}



// Add this new helper method
private findOriginalQuery(agent: any, editedQuery: any): any {
  if (!agent?.queries || !editedQuery?._id) return null;
  
  return agent.queries.find((q: any) => q._id === editedQuery._id);
}

confirmEdit() {
  if (!this.queryToEdit || !this.agentToEdit) return;

  this.isEditing = true;
  this._loadingService.show();

  const eventId = this.queryToEdit.event_id || this.queryToEdit._id || this.queryToEdit.prompt_id || '';
  const mapId = this.queryToEdit.map_id || this.generateUUID();

  const payload = {
    agency_id: this.selectedAgency?.agency_id || this.selectedAgency?._id || '',
    agent_id: this.agentToEdit.agent_id,
    prompt_title: this.editForm.promptTitle.trim(),
    user_query: this.editForm.prompt.trim(),
    event_id: eventId,
    map_id: mapId
  };

  console.log("confirmEdit Payload:", payload);

  this.promptRepoService.UpdatePrompt(payload).subscribe({
    next: (response) => {
      this._loadingService.hide();
      this.isEditing = false;

      if (response?.success) {
        this.showToast('success', 'Prompt updated successfully!');

        const agentIndex = this.selectedAgency.agents.findIndex((a: Agent) => 
          a.agent_id === this.agentToEdit.agent_id
        );

        if (agentIndex !== -1) {
          const queryIndex = this.selectedAgency.agents[agentIndex].queries.findIndex((q: any) => 
            q._id === this.queryToEdit._id
          );
          if (queryIndex !== -1) {
            this.selectedAgency.agents[agentIndex].queries[queryIndex].prompt_title = this.editForm.promptTitle;
            this.selectedAgency.agents[agentIndex].queries[queryIndex].user_query = this.editForm.prompt;
          }
        }
        this.fetchAgencies();
        this.cdr.detectChanges();
      } else {
        this.showToast('error', 'Failed to update: ' + (response?.message || ''));
      }

      this.editConfirmModal?.hide();
      this.clearEditModal();
    },
    error: (err) => {
      this._loadingService.hide();
      this.isEditing = false;
      console.error('Update error details:', err);
      this.showToast('error', 'Error updating prompt.');
    }
  });
}

cancelEdit() {
  this.editConfirmModal?.hide();
  this.clearEditModal();
}

clearEditModal() {
  this.queryToEdit = null;
  this.agentToEdit = null;
  this.isEditing = false;
  this.editForm = {
    promptTitle: '',
    prompt: ''
  };
}

deletePrompt(event: Event, query: any, agent: Agent) {
  event.stopImmediatePropagation();

  this.expandedQueryId = query._id;
  
  // Store the query and agent to delete
  this.queryToDelete = query;
  this.agentToDelete = agent;
  // Show confirmation modal
  this.deleteConfirmModal?.show();

  this.cdr.detectChanges();
}

confirmDelete() {
  if (!this.queryToDelete ) return;
  
  this.isDeleting = true;
  this._loadingService.show();
  
  const payload = {
    agency_id: this.selectedAgency?.agency_id || '',
    agent_id: this.agentToDelete.agent_id,
    prompt_title: this.queryToDelete.prompt_title,
    user_query: this.queryToDelete.user_query
  };
  
  this.promptRepoService.DeletePrompt(payload).subscribe({
    next: (response) => {
      this._loadingService.hide();
      this.isDeleting = false;
      
      if (response?.success) {
        this.showToast('success', 'Prompt deleted successfully!');
        // Remove from local data
        const agentIndex = this.selectedAgency.agents.findIndex((a: Agent) => a.agent_id === this.agentToDelete.agent_id);
        if (agentIndex !== -1) {
          this.selectedAgency.agents[agentIndex].queries = this.selectedAgency.agents[agentIndex].queries.filter((q: any) => q._id !== this.queryToDelete._id);
        }
        this.fetchAgencies();
        this.cdr.detectChanges();
      } else {
        this.showToast('error', 'Failed to delete: ' + (response?.message));
      }
      
      // Close modal
      this.deleteConfirmModal?.hide();
      this.clearDeleteModal();
    },
    error: (err) => {
      this._loadingService.hide();
      this.isDeleting = false;
      console.error('Delete error:', err);
      this.showToast('error', 'Error deleting prompt. Please try again.');
    }
  });
}

cancelDelete() {
  this.deleteConfirmModal?.hide();
  this.clearDeleteModal();
}

clearDeleteModal() {
  this.queryToDelete = null;
  this.isDeleting = false;
}

  @HostListener('document:click', ['$event'])
onClickOutside(event: Event) {
  // Close all menus
  this.promptActions = {};
}
  
  openNewPRModal() {
    this.resetForm();
    this.filteredAgentsForModal = [];

    const modalElement = document.getElementById('newPRModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }

  showAddPromptForm(agent?: any) {
    if (agent) {
      // Make sure we store the complete agent object
      this.currentAgent = agent;
      // Set both agency and agent in the form
      this.newPRForm = {
        agency: this.selectedAgency?.agency_name || '',
        agent: agent.name || '',  // This is important!
        promptTitle: '',
        prompt: '',
        created_by: this._stateService.getLoginDetails()?.Email|| '',
        map_id: this.generateUUID()
      };
      console.log("pay1 - with agent:", this.newPRForm);
    } else {
      this.newPRForm = {
        agency: this.selectedAgency?.agency_name || '',
        agent: '',  // Clear agent when no specific agent is passed
        promptTitle: '',
        prompt: '',
        created_by: this._stateService.getLoginDetails()?.Email || '',
        map_id: this.generateUUID()
      };
      console.log("pay2 - without agent:", this.newPRForm);
    }
    this.showAddPrompt = true;
    // Trigger change detection
    this.cdr.detectChanges();
  }

  private generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

  savePrompt(isFromModal: boolean = false) {
  if (!this.validatePromptFields()) {
    this.cdr.detectChanges();
    return;
  }

  const form = this.newPRForm;

  if (!form.promptTitle?.trim() || !form.prompt?.trim()) {
    this.showToast('error', 'Prompt Title and Prompt content are required!');
    return;
  }

  this._loadingService.show();

  if (!form.map_id) {
    form.map_id = this.generateUUID();
  }

  let agencyId: string | null = null;
  let agentId: string | null = null;

  if (isFromModal) {
    const selectedAgencyObj = this.agenciesWithAgents?.find((a: any) => 
      a.agency_name === form.agency
    );
    
    if (!selectedAgencyObj) {
      this._loadingService.hide();
      this.showToast('error', 'Please select a valid agency.');
      return;
    }

    const selectedAgentObj = selectedAgencyObj?.agents?.find((a: Agent) => 
      a.name === form.agent
    );

    if (!selectedAgentObj) {
      this._loadingService.hide();
      this.showToast('error', 'Please select a valid agent.');
      return;
    }

    agencyId = selectedAgencyObj.agency_id || selectedAgencyObj._id;
    agentId = selectedAgentObj.agent_id;
  } else {
    agencyId = this.selectedAgency?.agency_id || this.selectedAgency?._id;
    
    if (this.currentAgent) {
      agentId = this.currentAgent.agent_id;
    } else if (this.selectedAgency && form.agent) {
      const agent = this.selectedAgency.agents.find((a: Agent) => a.name === form.agent);
      agentId = agent?.agent_id;
    }
  }

  if (!agencyId || !agentId) {
    this._loadingService.hide();
    this.showToast('error', 'Could not determine Agency or Agent ID.');
    return;
  }

  const MapId = this.generateUUID();
  const now = new Date().toISOString();

  const payload = {
    agency_id: agencyId,
    agent_id: agentId,
    prompt_title: form.promptTitle.trim(),
    user_query: form.prompt.trim(),
    created_by: form.created_by,
    map_id: form.map_id
  };

  this.promptRepoService.savePrompt(payload).subscribe({
    next: (response) => {
      this._loadingService.hide();
      
      if (response?.success) {
        this.showToast('success', 'Prompt saved successfully!');

        const newQuery = {
          _id: response.data?._id || `temp_${Date.now()}`,
          user_query: form.prompt.trim(),
          prompt_title: form.promptTitle.trim(),
          map_id: form.map_id,
          created_ts: now,                    // ← Important
          updated_ts: now,
          execution_count: 0,
          average_rating: 0,
          prompt_output: ''                   // optional
        };

        // Add to current agent (if inline add)
        if (this.currentAgent && !isFromModal) {
          this.currentAgent.queries = [newQuery, ...(this.currentAgent.queries || [])]; // Add at top
        }

        // Refresh only if needed (modal case)
        if (isFromModal) {
          const modalElement = document.getElementById('newPRModal');
          if (modalElement) {
            const modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) modal.hide();
          }
          this.fetchAgencies(); // Full refresh for modal case
        } else {
          // For inline add → no full refresh, just local update + sort
          this.resetForm();
          this.showAddPrompt = false;
          this.cdr.detectChanges();
        }
      } else {
        this.showToast('error', 'Failed to save: ' + (response?.message || ''));
      }
    },
    error: (err) => {
      this._loadingService.hide();
      console.error('Save error:', err);
      this.showToast('error', 'Error saving prompt. Please try again.');
    }
  });
}

  closeModals() {
    // Close main modal
    const mainModal = document.getElementById('newPRModal');
    if (mainModal) {
      const modal = bootstrap.Modal.getInstance(mainModal);
      if (modal) modal.hide();
    }
    
    // Close agency modal if open
    this.showAddPrompt = false;
  }

  saveNewPR() {
    // Use the unified savePrompt method instead
    this.savePrompt(true);
  }

  // Single method that works for both cases
  getFilteredAgents(agency?: Agency): Agent[] {
    // If no agency provided, use selectedAgency
    const targetAgency = agency || this.selectedAgency;
    
    if (!targetAgency?.agents) return [];
    
    return targetAgency.agents.filter((agent: Agent) => 
      agent.agent_type_id !== 'MASTER'
    );
  }

  getTaskAgentCount(agency: Agency): number {
  if (!agency?.agents) return 0;
  return agency.agents.filter(agent => agent.agent_type_id !== 'MASTER').length;
}
  getTotalAgencies(): number {
    return this.apiData?.length || 0;
  }

  // Global search (Agency name + description)
onGlobalSearch() {
  if (!this.apiData) {
    this.filteredAgencies = [];
    return;
  }

  const term = this.globalSearchTerm.toLowerCase().trim();

  if (!term) {
    this.filteredAgencies = [...this.apiData];
    return;
  }

  this.filteredAgencies = this.apiData.filter((agency: any) => 
    agency.agency_name?.toLowerCase().includes(term) ||
    agency.agency_desc?.toLowerCase().includes(term)
  );
}

// Modal search - MASTER excluded + proper reset when clearing search
onModalSearch() {
  if (!this.selectedAgency?.agents) {
    this.filteredModalData = [];
    return;
  }

  const term = this.modalSearchTerm.toLowerCase().trim();

  // Always start with non-MASTER agents
  const baseAgents = this.getFilteredAgents(this.selectedAgency);

  if (!term) {
    // Reset to full non-master agents with complete queries
    this.filteredModalData = baseAgents.map((agent: Agent) => ({
      ...agent,
      queries: [...(agent.queries || [])]
    }));
    this.cdr.detectChanges();
    return;
  }

  // Perform search
  const results: Agent[] = [];

  for (const agent of baseAgents) {
    const agentNameMatch = agent.name?.toLowerCase().includes(term) || false;

    const filteredQueries = (agent.queries || []).filter((query: any) =>
      query.prompt_title?.toLowerCase().includes(term) ||
      query.user_query?.toLowerCase().includes(term)
    );

    if (agentNameMatch || filteredQueries.length > 0) {
      results.push({
        ...agent,
        queries: filteredQueries.length > 0 ? filteredQueries : [...(agent.queries || [])]
      });
    }
  }

  this.filteredModalData = results;
  this.cdr.detectChanges();
}

  closeAgencyModal() {
  this.modalSearchTerm = '';
  this.filteredModalData = [];
}

  onAgencyFilterChange() {
  if (!this.filterAgency) {
    this.filteredFilterAgents = this.allAvailableAgents;
    return;
  }

  this.filteredFilterAgents = this.allAvailableAgents.filter(
    agent => agent.agency_name === this.filterAgency
  );
}

// Prepare all agents for filter dropdown (with unique agent names)
private prepareFilterData() {
  this.allAvailableAgents = [];
  if (!this.apiData) return;

  const agentMap = new Map<string, any>(); // Use Map to ensure uniqueness by agent name

  this.apiData.forEach((agency: any) => {
    const nonMaster = this.getFilteredAgents(agency);
    
    nonMaster.forEach(agent => {
      const agentName = agent.name?.trim();
      
      // Keep only the first occurrence of each agent name (removes duplicates)
      if (agentName && !agentMap.has(agentName)) {
        agentMap.set(agentName, {
          ...agent,
          agency_name: agency.agency_name
        });
      }
    });
  });

  this.allAvailableAgents = Array.from(agentMap.values());
  this.filteredFilterAgents = [...this.allAvailableAgents];

  console.log(`Prepared ${this.allAvailableAgents.length} unique agents for filter`);
}

// Main Apply Filters Method
applyFilters() {
  if (!this.filterAgency && !this.filterAgent) {
    this.filteredAgencies = [...this.apiData];
    this.cdr.detectChanges();
    return;
  }

  this.filteredAgencies = this.apiData.filter((agency: any) => {
    const agencyMatch = !this.filterAgency || agency.agency_name === this.filterAgency;

    if (!agencyMatch) return false;

    if (!this.filterAgent) return true;

    // Check if agency has the selected agent
    const agents = this.getFilteredAgents(agency);
    return agents.some(agent => agent.name === this.filterAgent);
  });

  this.cdr.detectChanges();
}

// Clear Filters
clearFilters() {
  this.filterAgency = '';
  this.filterAgent = '';
  this.filteredFilterAgents = [...this.allAvailableAgents];
  this.filteredAgencies = [...this.apiData];
  this.cdr.detectChanges();
}

// Add these properties (already present)
promptTitleError: string = '';
promptContentError: string = '';

// Updated Validation Method
isValidPromptContent(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  const trimmed = value.trim();
  
  // Must contain at least ONE alphabet letter (a-z or A-Z)
  const hasLetter = /[a-zA-Z]/.test(trimmed);
  
  return hasLetter;
}

// Updated Validation Fields Method
validatePromptFields(): boolean {
  this.promptTitleError = '';
  this.promptContentError = '';

  const title = this.newPRForm.promptTitle?.trim();
  const prompt = this.newPRForm.prompt?.trim();

  let isValid = true;

  if (!title) {
    this.promptTitleError = 'Prompt Title is required.';
    isValid = false;
  } else if (!this.isValidPromptContent(title)) {
    this.promptTitleError = 'Please give proper content for title. Only numbers and special characters are not allowed.';
    isValid = false;
  }

  if (!prompt) {
    this.promptContentError = 'Prompt content is required.';
    isValid = false;
  } else if (!this.isValidPromptContent(prompt)) {
    this.promptContentError = 'Please give proper content. Only numbers and special characters are not allowed.';
    isValid = false;
  }

  return isValid;
}

// Clear errors when form is reset
resetForm() {
  this.newPRForm = {
    agency: '',
    agent: '',
    promptTitle: '',
    prompt: '',
    created_by: this._stateService.getLoginDetails()?.Email || '',
    map_id: this.generateUUID()
  };
  this.promptTitleError = '';
  this.promptContentError = '';
  this.currentAgent = null;
}

// Real-time validation for individual fields (called on blur)
onTitleBlur() {
  const title = this.newPRForm.promptTitle?.trim();
  if (!title) {
    this.promptTitleError = 'Prompt Title is required.';
  } else if (!this.isValidPromptContent(title)) {
    this.promptTitleError = 'Please give proper content for title. Only numbers and special characters are not allowed.';
  } else {
    this.promptTitleError = '';
  }
}

onPromptBlur() {
  const prompt = this.newPRForm.prompt?.trim();
  if (!prompt) {
    this.promptContentError = 'Prompt content is required.';
  } else if (!this.isValidPromptContent(prompt)) {
    this.promptContentError = 'Please give proper content. Only numbers and special characters are not allowed.';
  } else {
    this.promptContentError = '';
  }
}

getPromptMetrics(query: any): PromptMetrics {
  const metrics: PromptMetrics = {
    correctness: 0,
    accuracy: 0,
    safety: 0,
    coherence: 0,
    conciseness: 0,
    relevance: 0,
    latency: undefined,
    status: undefined
  };

  if (!query) {
    return metrics;
  }

  // Priority 1: Use pre-computed metrics object
  if (query.metrics && typeof query.metrics === 'object') {
    const m = query.metrics;
    metrics.correctness = m['correctness/mean'] ?? 0;
    metrics.accuracy = m['accuracy/mean'] !== undefined ? Math.round(m['accuracy/mean'] * 100) : 0;
    metrics.safety = m['safety/mean'] ?? 0;
    metrics.coherence = m['coherence/mean'] ?? 0;
    metrics.conciseness = m['conciseness/mean'] ?? 0;
    metrics.relevance = m['relevance/mean'] ?? 0;
    metrics.latency = this.getLatency(query);
    return metrics;
  }

  // Priority 2: Fallback to detailed_results
  if (query.detailed_results?.length > 0) {
    const result = query.detailed_results[0];
    metrics.correctness = result['correctness/value'] ?? 0;
    metrics.accuracy = result['accuracy/value'] !== undefined ? Math.round(result['accuracy/value'] * 100) : 0;
    metrics.safety = result['safety/value'] ?? 0;
    metrics.coherence = result['coherence/value'] ?? 0;
    metrics.conciseness = result['conciseness/value'] ?? 0;
    metrics.relevance = result['relevance/value'] ?? 0;
    metrics.latency = this.getLatency(query);
    return metrics;
  }

  return metrics; // All defaults when no data
}

getLatency(query: any): number | undefined {
  // Priority 1: New trace_duration field
  if (query?.trace_info?.trace_summary?.[0]?.trace_duration !== undefined) {
    const duration = query.trace_info.trace_summary[0].trace_duration;
    return Number(duration); // Ensure it's a number
  }

  // Priority 2: Fallback (old fields)
  if (query.execution_duration !== undefined) {
    return Number(query.execution_duration);
  }
  if (query.detailed_results?.[0]?.execution_duration !== undefined) {
    return Number(query.detailed_results[0].execution_duration);
  }

  return undefined;
}

getPaginatedQueries(agent: any): any[] {
  if (!agent?.queries?.length) return [];

  const sortedQueries = [...agent.queries].sort((a, b) => {
    const timeA = a.created_ts ? new Date(a.created_ts).getTime() : 0;
    const timeB = b.created_ts ? new Date(b.created_ts).getTime() : 0;
    
    if (timeB !== timeA) return timeB - timeA; // Newest first

    // Fallback to _id 
    return (b._id || '').toString().localeCompare((a._id || '').toString());
  });

  const page = this.promptPageMap[agent.agent_id] || 1;
  const start = (page - 1) * this.itemsPerPage;

  return sortedQueries.slice(start, start + this.itemsPerPage);
}

getTotalPrompts(agent: any): number {
  return agent?.queries?.length || 0;
}

getPromptStartItem(agent: any): number {
  const page = this.promptPageMap[agent.agent_id] || 1;
  return (page - 1) * this.itemsPerPage + 1;
}

getPromptEndItem(agent: any): number {
  const page = this.promptPageMap[agent.agent_id] || 1;
  const total = this.getTotalPrompts(agent);
  return Math.min(page * this.itemsPerPage, total);
}

changePromptPage(agent: any, newPage: number): void {
  if (newPage < 1 || newPage > this.getTotalPromptPages(agent)) return;
  this.promptPageMap[agent.agent_id] = newPage;
  this.cdr.detectChanges();
}

getTotalPromptPages(agent: any): number {
  const total = this.getTotalPrompts(agent);
  return Math.ceil(total / this.itemsPerPage) || 1;
}

goToPromptPage(agent: any, page: number): void {
  this.changePromptPage(agent, page);
}

// Add this method at the bottom of your class
getDisplayTitle(query: any): string {
  if (query?.prompt_title && query.prompt_title.trim() !== '') {
    return query.prompt_title.trim();
  }

  // Fallback using the provided logic
  const text = query?.prompt_output || query?.user_query || '';
  const agentName = query?.agent_name || '';

  let title = 'Response';

  if (typeof text !== 'string' || !text) {
    return agentName || title;
  }

  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  if (!lines.length) {
    return agentName || title;
  }

  let titleLineIndex = lines.findIndex(item =>
    ['#', 'title:', '**'].some(s => item.toLowerCase().includes(s))
  );

  if (titleLineIndex === -1) {
    titleLineIndex = 0;
  }

  const line = lines[titleLineIndex];
  const parts = line.split(':').filter(Boolean);

  if (parts.length > 1) {
    title = parts[1];
  } else {
    title = parts[0] || title;
  }

  const output = title.replace(/^[#* ]+|[#* ]+$/g, "").trim();
  console.log("title field",output)
  return output || agentName || 'Untitled Prompt';
}

// Toggle agent accordion
toggleAgent(agent: Agent, event: Event) {
  event.stopPropagation();
  
  // Close current agent if it's the same one being clicked
  if (this.expandedAgentId === agent.agent_id) {
    this.expandedAgentId = null;
    this.expandedQueryId = null; // Also close any open query
  } else {
    // Close other agents and queries
    this.expandedAgentId = agent.agent_id;
    this.expandedQueryId = null;
  }
  
  this.cdr.detectChanges();
}

// Toggle query accordion
toggleQuery(agent: Agent, query: any, event: Event) {
  event.stopPropagation();

  const isCurrentlyOpen = this.expandedQueryId === query._id;

  if (isCurrentlyOpen) {
    // Closing the accordion → also close its menu
    this.promptActions[query._id] = false;
    this.expandedQueryId = null;
  } else {
    // Opening the accordion
    this.expandedQueryId = query._id;
  }

  this.cdr.detectChanges();
}

// Improved & Strict Title Extraction
extractTitleFromResponse(text: string, agentName?: string): string {
  if (typeof text !== 'string' || !text.trim()) {
    return agentName || 'Untitled Prompt';
  }

  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  if (!lines.length) {
    return agentName || 'Untitled Prompt';
  }

  // Find the first meaningful header (Priority order)
  let titleLineIndex = lines.findIndex(line => {
    const trimmed = line.trim();
    
    // Strong match for top-level headers
    return (
      /^#\s+/.test(trimmed) ||                    // # Main Title
      trimmed.toLowerCase().startsWith('title:') || 
      trimmed.startsWith('## ') && !trimmed.includes('EPIC') // Avoid secondary headers
    );
  });

  if (titleLineIndex === -1) {
    titleLineIndex = 0; // fallback to first line
  }

  let line = lines[titleLineIndex];

  // Clean the line aggressively
  line = line
    .replace(/^#{1,6}\s+/, '')           // Remove markdown header markers
    .replace(/^Title:\s*/i, '')          // Remove "Title:" prefix
    .replace(/^\*\*|\*\*$/g, '')         // Remove bold markers
    .replace(/\\n/g, ' ')                // Remove escaped newlines
    .trim();

  // Stop at first colon or double newline indicator
  const cleanTitle = line.split(/[:|\n#]/)[0].trim();

  return cleanTitle || agentName || 'Untitled Prompt';
}

// Auto update prompts with EXACTLY "No Title" only - BATCH + INITIAL LOAD ONLY
autoFixNoTitlePrompts() {
  if (!this.apiData) return;

  const updatePayloads: any[] = [];
  const processedIds = new Set<string>();

  this.apiData.forEach((agency: any) => {
    agency.agents?.forEach((agent: any) => {
      agent.queries?.forEach((query: any) => {
        if (!query?._id || processedIds.has(query._id)) return;
        processedIds.add(query._id);

        const currentTitle = query.prompt_title;

        // STRICT CHECK: ONLY "No Title" string — nothing else (null, "", undefined, etc.)
        if (currentTitle !== "No Title") {
          return;
        }

        const newTitle = this.extractTitleFromResponse(query.prompt_output, agent.name);

        if (newTitle && newTitle !== "No Title" && newTitle.trim() !== "") {
          console.log(`Preparing batch fix for query ${query._id}: "${newTitle.substring(0, 100)}..."`);

          const payload = {
            agency_id: agency.agency_id || agency._id,
            agent_id: agent.agent_id,
            prompt_title: newTitle,
            user_query: query.user_query,
            event_id: query.event_id || '',
            map_id: query.map_id || ''
          };

          updatePayloads.push(payload);

          // Optimistically update UI
          query.prompt_title = newTitle;
        }
      });
    });
  });

  if (updatePayloads.length === 0) {
    console.log('No prompts with exact "No Title" found.');
    return;
  }

  console.log(`Sending batch update for ${updatePayloads.length} "No Title" prompts...`);

  this._loadingService.show();

  this.promptRepoService.batchUpdatePrompts({ updates: updatePayloads }).subscribe({
    next: (response) => {
      this._loadingService.hide();
      
      if (response?.success) {
        this.cdr.detectChanges();
        console.log(`Successfully batch-updated ${updatePayloads.length} prompts.`);
        
        if (updatePayloads.length >= 3) {
          console.log('success', `${updatePayloads.length} prompt titles were auto-updated.`);
        }
      }
    },
    error: (err) => {
      this._loadingService.hide();
      console.error('Batch update failed:', err);
      console.log('error', 'Some prompt titles could not be auto-updated.');
    }
  });
}

getExecutionStatus(query: any): { label: string; class: string } {
  if (!query) {
    return { label: 'Unknown', class: 'bg-secondary' };
  }

  const status = (query.status || '').toString().toLowerCase().trim();
  const executionCount = Number(query.execution_count || 0);

  // New Condition: All metrics are 0 but used more than once → Re-execute
  if (executionCount > 0) {
    const metrics = this.getPromptMetrics(query);
    const allMetricsZero = 
      (!metrics.correctness || metrics.correctness === 0) &&
      (!metrics.coherence || metrics.coherence === 0) &&
      (!metrics.relevance || metrics.relevance === 0) &&
      (!metrics.conciseness || metrics.conciseness === 0) &&
      (!metrics.safety || metrics.safety === 0) &&
      (!metrics.accuracy || metrics.accuracy === 0);

    if (allMetricsZero) {
      return { 
        label: 'Re-execute', 
        class: 'bg-warning text-dark' 
      };
    }
  }

  // Existing logic
  if (status === 'completed') {
    return { label: 'Completed', class: 'bg-success text-white' };
  } 
  else if (['inprogress', 'in_progress', 'pending'].includes(status)) {
    return { label: 'In Progress', class: 'bg-warning text-dark' };
  } 
  else if (status === 'stored' || query.is_stored_prompt === true) {
    return { 
      label: 'Not Executed', 
      class: 'bg-secondary text-white'
    };
  }
  else {
    return { 
      label: status ? status.charAt(0).toUpperCase() + status.slice(1) : 'Not Executed', 
      class: 'bg-secondary text-white' 
    };
  }
}

}