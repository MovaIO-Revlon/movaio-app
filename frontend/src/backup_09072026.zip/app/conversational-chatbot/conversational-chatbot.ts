import { Component, ElementRef, NgZone, ViewChild, AfterViewChecked, OnDestroy, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import MarkdownIt from 'markdown-it';
import { HomeService } from '../services/home.service';
import { Header } from '../header/header';

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text?: string;
  markdown?: string;
  plain?: string;
  html?: string;
  thinking?: boolean;
  attachments?: { name: string }[];
  suggested?: string[];
}

@Component({
  selector: 'app-conversational-chatbot',
  imports: [CommonModule, FormsModule, Header],
  templateUrl: './conversational-chatbot.html',
  styleUrl: './conversational-chatbot.css'
})
export class ConversationalChatbot implements OnInit, AfterViewChecked, OnDestroy {
  @ViewChild('messagesList') messagesList!: ElementRef;

  messages: Message[] = [];
  draft = '';
  isRecording = false;
  suggestions: string[] = [];
  pendingAttachments: { name: string; file?: File }[] = [];
  showThinking: boolean = false;
  chatResponses: any[] = [];
  private suggestionSub?: Subscription;

  agencies: any[] = [];
  filteredAgents: any[] = [];
  selectedAgencyId: any = null;
  selectedAgentId: any = null;
  agencyLoading = false;
  currentSessionId: string = '';
  sidebarCollapsed: boolean = true;

  private recognition: any = null;
  private lastUserMessage: Message | null = null;
  private readonly markdownParser = new MarkdownIt({ html: false, linkify: true, typographer: true });

  constructor(private readonly ngZone: NgZone,
    private readonly _homeService: HomeService,
    private readonly cdRef: ChangeDetectorRef
  ) {
    // chat starts blank until an agent is selected
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  ngOnInit(): void {
    this.loadAgencies();
  }

  ngAfterViewChecked(): void {
    this.scrollToBottom();
  }

  get selectedAgency() {
    return this.agencies.find(a => a.agency_id == this.selectedAgencyId);
  }

  get selectedAgent() {
    return this.filteredAgents.find(agent => agent.agent_id == this.selectedAgentId);
  }

  loadAgencies(): void {
    this.agencyLoading = true;
    this._homeService.getAgencyWithAgents().subscribe({
      next: (res: any) => {
        this.agencies = [...(res?.data || [])];
        this.cdRef.detectChanges();
      },
      error: () => {
        this.agencies = [];
        this.cdRef.detectChanges();
      },
      complete: () => {
        this.agencyLoading = false;
        this.cdRef.detectChanges();
      }
    });
  }

  private filterInteractiveAgents(agents: any[] = []): any[] {
    return agents.filter(agent => agent.agent_type_id === 'CONVERSATIONAL');
  }

  onAgencyChange(agencyId: any): void {
    this.selectedAgencyId = agencyId;
    this.selectedAgentId = null;
    this.sidebarCollapsed = false;
    this.filteredAgents = this.filterInteractiveAgents(this.selectedAgency?.agents || []);
    this.currentSessionId = '';
    this.chatResponses = [];
    this.suggestions = [];
    this.draft = '';
    this.pendingAttachments = [];
    this.cdRef.detectChanges();
  }

  onAgentChange(agentId: string): void {
    const isNewAgent = this.selectedAgentId !== agentId;
    this.selectedAgentId = agentId;
    if (isNewAgent) {
      this.chatResponses = [];
      this.suggestions = [];
      this.draft = '';
      this.pendingAttachments = [];
    }

    if (agentId) {
      this.sidebarCollapsed = true;
      this.currentSessionId = this.generateUUID();
      this.loadRecentQuerySuggestions(agentId);
      if (this.chatResponses.length === 0) {
        const welcomeText = `Welcome to ${this.selectedAgent?.name || 'Agent'}, Please type your query.`;
        this.chatResponses.push({
          id: this.id(),
          role: 'assistant',
          text: welcomeText,
          html: `<div class="streamed-response">${welcomeText}</div>`,
          showThinking: false,
          suggested: ['Show docs', 'Upload a file', 'Give me an example']
        });
      }
    }
  }

  trackByAgency(index: number, agency: any) {
    return agency.agency_id;
  }

  trackByAgent(index: number, agent: any) {
    return agent.agent_id;
  }

  canSend(): boolean {
    return !!this.selectedAgentId && (((this.draft && this.draft.trim().length > 0) || this.pendingAttachments.length > 0));
  }

  onSend(): void {
    if (!this.selectedAgentId) return;
    const text = this.draft?.trim();
    if (!text && this.pendingAttachments.length === 0) return;

    const attachments = this.pendingAttachments.map(a => ({ name: a.name }));

    const userMsg: Message = { id: this.id(), role: 'user', text: text || (attachments.length ? `Sent ${attachments.length} file(s)` : ''), attachments };
    this.messages.push(userMsg);
    this.chatResponses.push({
       id: this.id(), role: 'user', text: text || (attachments.length ? `Sent ${attachments.length} file(s)` : ''), attachments 
    })
    this.lastUserMessage = userMsg;
    this.draft = '';
    this.pendingAttachments = [];

    this.askAssistant(userMsg);
  }
  onFileSelected(event: any): void {
    const files: FileList = event.target.files;
    if (!files || files.length === 0) return;
    const arr = Array.from(files).map(f => ({ name: f.name, file: f }));
    // add to pending attachments to show in composer before sending
    this.pendingAttachments.push(...arr);
  }

  removeAttachment(index: number): void {
    if (index >= 0 && index < this.pendingAttachments.length) this.pendingAttachments.splice(index, 1);
  }

  copyMessage(m: Message): void {
    let text = m.text || '';
    if (!text && m.html) {
      text = m.html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    }
    if (!text) return;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => { });
    }
  }

  downloadResponse(m: Message): void {
    let text = m.markdown || m.text || '';
    if (!text && m.plain) {
      text = m.plain;
    }
    if (!text && m.html) {
      text = m.html.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    }
    if (!text) return;

    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `assistant-response-${Date.now()}.md`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  regenerate(m: Message): void {
    // If regenerating an assistant message, re-run the assistant using the last user message
    const seed = this.lastUserMessage;
    if (seed) this.askAssistant(seed, true);
  }

  startNewChat(): void {
    if (!this.selectedAgentId) return;

    this.currentSessionId = this.generateUUID();
    const welcomeText = `Welcome to ${this.selectedAgent?.name || 'Agent'}, Please type your query.`;
    this.chatResponses = [{
      id: this.id(),
      role: 'assistant',
      text: welcomeText,
      html: `<div class="streamed-response">${welcomeText}</div>`,
      showThinking: false,
      suggested: ['Show docs', 'Upload a file', 'Give me an example']
    }];
    this.draft = '';
    this.pendingAttachments = [];
    this.loadRecentQuerySuggestions(this.selectedAgentId);
    this.cdRef.detectChanges();
  }

  selectSuggestion(s: string): void {
    this.draft = s;
    this.cdRef.detectChanges();
  }

  private loadRecentQuerySuggestions(agentId: string | null): void {
    this.suggestionSub?.unsubscribe();
    this.suggestions = [];

    if (!agentId) {
      return;
    }

    const payload = { agent_id: agentId };
    this.suggestionSub = this._homeService.getRecentDataAgent(payload).subscribe({
      next: (res: any) => {
        const items = Array.isArray(res?.data) ? res.data : [];
        const queries = items
          .map((item: any) => item?.user_query)
          .filter((query: any) => typeof query === 'string' && query.trim().length > 0);

        const uniqueQueries = queries.filter((query: string, index: number) => {
          const normalized = query.trim().toLowerCase();
          return normalized && queries.findIndex((item: string) => item.trim().toLowerCase() === normalized) === index;
        });

        this.suggestions = uniqueQueries.slice(-3).reverse();
        this.cdRef.detectChanges();
      },
      error: (err: any) => {
        console.error('Failed to load suggestions:', err);
        this.suggestions = [];
      }
    });
  }

  truncateSuggestion(text: string, maxLength = 60): string {
    if (!text) return '';
    return text.length > maxLength ? `${text.slice(0, maxLength).trim()}...` : text;
  }

  ngOnDestroy(): void {
    this.suggestionSub?.unsubscribe();
  }

  toggleVoice(): void {
    const win: any = globalThis as any;
    const SpeechRecognition = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Voice input is not supported in this browser.');
      return;
    }

    if (!this.recognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      this.recognition.onresult = (evt: any) => {
        const transcript = Array.from(evt.results).map((r: any) => r[0].transcript).join('');
        this.ngZone.run(() => this.draft = transcript);
      };
      this.recognition.onend = () => {
        this.ngZone.run(() => this.isRecording = false);
      };
    }

    if (this.isRecording) {
      this.recognition.stop();
      this.isRecording = false;
    } else {
      this.recognition.start();
      this.isRecording = true;
    }
  }

  private askAssistant(userMsg: Message, isRegenerate = false): void {
    // Add assistant thinking message
    // const thinkingMsg: Message = { id: this.id(), role: 'assistant', thinking: true };
    // this.messages.push(thinkingMsg);
    this.submitQuery(userMsg.text || '');

    // // Simulated delay for thinking/response
    // setTimeout(() => {
    //   // Replace thinking message with a fake response
    //   const index = this.messages.findIndex(m => m.id === thinkingMsg.id);
    //   if (index === -1) return;

    //   const replyText = this.simulateResponse(userMsg, isRegenerate);
    //   const replySuggested = ['Thanks', 'Explain more', 'Short summary'];
    //   const reply: Message = { id: thinkingMsg.id, role: 'assistant', text: replyText, suggested: replySuggested };
    //   this.messages[index] = reply;
    //   // expose suggested actions globally near the composer
    //   this.suggestions = replySuggested;
    // }, 1200 + Math.random() * 800);
  }

  private simulateResponse(userMsg: Message, isRegenerate: boolean): string {
    if (userMsg.attachments?.length) {
      return `I received ${userMsg.attachments.length} file(s). What would you like me to do with them?`;
    }
    if (isRegenerate) {
      return `Here's an alternative answer to: "${userMsg.text}"`;
    }
    return `Simulated response to: "${userMsg.text}"`;
  }

  private scrollToBottom(): void {
    try {
      const el = this.messagesList?.nativeElement;
      if (el) el.scrollTop = el.scrollHeight;
    } catch (error) { console.warn('scrollToBottom failed', error); }
  }

  private id(): string {
    return Math.random().toString(36).slice(2, 10);
  }

  private generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.trunc(Math.random() * 16);
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

extractTitleFromResponse(text:any, agentName?: string) { 
  let title = 'Response';

  if (typeof text !== 'string' || !text) {
    return agentName || title;
  }
  
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  if (!lines.length) {
    return agentName || title;
  }

  let titleLineIndex = lines.findIndex(item =>
    ['#', 'title:', "**"].some(s => item.toLowerCase().includes(s))
  );

  if (titleLineIndex === -1) {
    titleLineIndex = 0;
  }

  const line = lines[titleLineIndex];

  const parts = line.split(':').filter(Boolean);

  if (parts.length > 1) {
    title = parts[1];
  } else {
    title = parts[0];
  }

  const output = title.replace(/^[#* ]+|[#* ]+$/g, "");

  return output || agentName || title;
}

  submitQuery(text: string) {
    const agentId = this.selectedAgentId || '69a59f503eebff252d906780';
    const sessionId = this.currentSessionId || this.generateUUID();
    const eventId = this.generateUUID();
    const mapId = this.generateUUID();

    const query = text.trim();
    if (!query) {
      return;
    }

    const payload: any = {
      userQuery: query,
      agent_id: agentId,
      user_id: 'NaveenKumar.ReddyR@movate.com',
      master_agent_id: '69a71759ad9aa4e5502916fc',
      session_id: sessionId,
      event_id: eventId,
      map_id: mapId,
      prompt_title: '',
      isSavedToRepo: false
    };
    console.log('Payload for chatbotAgent with session_id:', payload);

    this.showThinking = false;

    const streamIndex = this.chatResponses.push({
      isLoading: true,
      title: 'Generating...',
      html: '',
      plain: '',
      json: {},
      table: { headers: [], rows: [] },
      explanation: '',
      thinking: true,
      showThinking: true,
      traceDetails: null,
      logDetails: [],
      showChatMessages: false,
      showChatMessagesTab: false,
      activeTab: 'trace',
      isLoadingExplanation: true,
      explanationDataLoaded: false,
      role: 'assistant'
    }) - 1;

    const unifiedResponse = this._homeService.chatbotAgentUnified(payload);
  // Handle trace details
  // let traceDetails: any = null;
  // let traceDetailsSubscription = unifiedResponse.traceDetails.subscribe({
  //   next: (chunk) => {
  //     if (chunk.type === 'trace_details') {
  //     traceDetails = chunk.data;
  //     this.chatResponses[streamIndex].traceDetails = traceDetails;
  //     this.chatResponses[streamIndex].isLoadingExplanation = false;
  //     this.chatResponses[streamIndex].explanationDataLoaded = true;
  //     this.cdRef.detectChanges();
  //   }
  //   },
  //   error: (err) => console.error('❌ Error in trace details:', err)
  // });

  // Handle log details
//   let logDetails: any[] = [];
//   let logDetailsSubscription = unifiedResponse.logDetails.subscribe({
//   next: (chunk) => {
//     if (this.isProcessingCompleted) return;
//     if (this.isCompletionMessage(chunk)) {
//       console.log('Metrics completed — showing thinking with logs');
//       this.isLoading = false;
//       this.isProcessingCompleted = true;
//       const logsHtml = this.createLogsHtml(this.logsDuringLoading);
//       if (this.chatResponses[streamIndex]) {
//         this.chatResponses[streamIndex].thinkingLogs = this.logsDuringLoading.map(log => ({
//           title: log.title,
//           content: this.createLogDetails(log.originalData || log),
//           expanded: false
//         }));
//       }
//       // ✅ IMMEDIATELY FORMAT THE RESPONSE WHEN showThinking BECOMES TRUE
//       this.formatAndSetResponse(streamIndex, accumulatedText);
//       this.showThinking = true;
//       this.cdRef.detectChanges();
//       return;
//     }
//     if (chunk.type === 'log') {
//       logDetails.push(chunk.data);
//       if (!this.hasRealLogs) this.hasRealLogs = true;
//       const logEntry = this.createLogStep(chunk.data);
//       this.logsDuringLoading.push(logEntry);
//       this.cdRef.detectChanges();
//       this.scrollToBottom();
//     }
//   },
//   error: (err) => {
//     console.error(' Error in log details:', err);
//     if (!this.isProcessingCompleted) this.stopProcessingAndShowResults();
//   }
// });
  // Handle stream content
  let accumulatedText = '';
  let hasRenderedResponse = false;

  const renderStreamedText = (textChunk: string) => {
    accumulatedText += textChunk;
    // Convert both escaped (\\n) and literal (\n) to actual newlines
    const displayText = accumulatedText
      .replaceAll(String.raw`\n`, '\n')  // Handle literal \n
      .replaceAll(String.raw`\\n`, '\n'); // Handle escaped \\n
    const cleanedDisplay = displayText
      .replace(/```psv[\s\S]*?```/gi, '')
      .replace(/```\s*psv[\s\S]*?```/gi, '')
      .replace(/\n\s*\n\s*\n/g, '\n\n')
      .trim();

    const markdownHtml = this.markdownParser.render(cleanedDisplay);
    const plainText = markdownHtml
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    this.chatResponses[streamIndex] = {
      ...this.chatResponses[streamIndex],
      isLoading: false,
      event_id: eventId,
      map_id: mapId,
      markdown: cleanedDisplay,
      plain: plainText,
      text: plainText,
      html: `<div class="streamed-response">${markdownHtml}</div>`,
      title: this.selectedAgent?.name || 'Assistant',
      explanation: plainText,
      thinking: false,
      showThinking: false,
      activeTab: 'trace',
      isLoadingExplanation: false,
      explanationDataLoaded: true,
      role: 'assistant'
    };
    hasRenderedResponse = true;
    this.cdRef.detectChanges();
    this.scrollToBottom();
  };

  unifiedResponse.stream.subscribe({
    next: (chunk) => {
      if (chunk === 'end' || chunk === '[DONE]' || chunk === '[done]') {
        return;
      }

      let textChunk = '';
      if (typeof chunk === 'string') {
        textChunk = chunk.replace(/^data:\s*/i, '').replaceAll(String.raw`\\"`, '"').replaceAll(String.raw`\\t`, ' ');
      } else if (chunk && typeof chunk === 'object' && 'data' in chunk) {
        textChunk = String((chunk as any).data || '');
      }

      if (!textChunk) {
        return;
      }

      renderStreamedText(textChunk);
    },
    error: (err) => {
      console.error('❌ Streaming error:', err);
      const currentResponse = this.chatResponses[streamIndex] || {};
      const responseAlreadyRendered = hasRenderedResponse || (!!currentResponse.html && currentResponse.html.toString().trim() !== '');

      if (responseAlreadyRendered) {
        this.chatResponses[streamIndex] = {
          ...currentResponse,
          isLoading: false,
          isLoadingExplanation: false,
          explanationDataLoaded: true,
          thinking: false,
          showThinking: false
        };
      } else {
        this.chatResponses[streamIndex] = {
          ...currentResponse,
          html: '<div class="chat-line error">Failed to generate response.</div>',
          plain: 'Failed to generate response.',
          json: { error: true, message: 'Failed to generate response.' },
          table: { headers: [], rows: [] },
          title: 'Error',
          explanation: 'Failed to generate response',
          thinking: false,
          showThinking: false,
          isLoading: false,
          isLoadingExplanation: false,
          explanationDataLoaded: true
        };
      }
      this.cdRef.detectChanges();
    },
    complete: () => {
      this.chatResponses[streamIndex] = {
        ...this.chatResponses[streamIndex],
        isLoading: false,
        isLoadingExplanation: false,
        explanationDataLoaded: true,
        thinking: false,
        showThinking: false
      };
      this.cdRef.detectChanges();
    }
  });
}
}
