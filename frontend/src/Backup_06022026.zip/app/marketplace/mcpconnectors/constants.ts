import { IUseCase, TConnectorType, TEntity } from '../../types';

export interface IConnector {
  label: string;
  key: TConnectorType;
  icon: string;
  disabled?: boolean;
}

export interface IConnectorGroup {
  name: string;
  connectors: IConnector[];
}

export const CONNECTOR_GROUPS: IConnectorGroup[] = [
  {
    name: 'Excel/Doc',
    connectors: [
      {
        label: 'Excel',
        key: 'excel',
        icon: 'assets/img/excel_icon.png',
      },
      {
        label: 'Docx',
        key: 'docx',
        icon: 'assets/img/docx.png',
        disabled: true,
      },
      {
        label: 'PPT',
        key: 'ppt',
        icon: 'assets/img/ppt.png',
        disabled: true,
      },
      {
        label: 'PDF',
        key: 'pdf',
        icon: 'assets/img/pdf.png',
        disabled: true,
      },
    ],
  },
  {
    name: 'ITSM Tools',
    connectors: [
      {
        label: 'Team Dynamix',
        key: 'team_dynamix',
        icon: 'assets/img/team_dynamix.png',
      },
      {
        label: 'Service Now',
        key: 'service_now',
        icon: 'assets/img/service_now.png',
        disabled: true,
      },
    ],
  },
  {
    name: 'Agile Tools',
    connectors: [
      {
        label: 'JIRA',
        key: 'jira',
        icon: 'assets/img/jira_icon.png',
      },
      {
        label: 'Azure DevOps',
        key: 'azure_devops',
        icon: 'assets/img/azure_devops.png',
        disabled: true,
      },
      {
        label: 'Rally',
        key: 'rally',
        icon: 'assets/img/rally.png',
        disabled: true,
      },
    ],
  },
  {
    name: 'Version Control Tools',
    connectors: [
      {
        label: 'GitHub',
        key: 'github',
        icon: 'assets/img/github.png',
        disabled: true,
      },
      {
        label: 'SVN',
        key: 'svn',
        icon: 'assets/img/svn.png',
        disabled: true,
      },
    ],
  },
];

export const CONNECTOR_ICON_MAP: Record<TConnectorType, string> =
  CONNECTOR_GROUPS.map((item) => item.connectors)
    .flat(1)
    .reduce(
      (acc, g) => {
        acc[g.key] = g.icon;
        return acc;
      },
      {} as Record<TConnectorType, string>,
    );

export interface IField {
  name: string;
  key: string;
  default?: string;
  readonly?: boolean;
  required?: boolean;
}

export const ENTITY_DEFAULT_FIELDS: Record<TEntity, IField[]> = {
  incident: [
    { name: 'ID', key: 'id', default: 'Ticket Id', readonly: true },
    {
      name: 'Issue Type',
      key: 'issue_type',
      default: 'issue_type',
      readonly: true,
    },
    {
      name: 'Application',
      key: 'application',
      default: 'application',
      readonly: true,
    },
    {
      name: 'Created Date',
      key: 'created_date',
      default: 'created_date',
      readonly: true,
    },
    {
      name: 'Resolved Date',
      key: 'resolved_date',
      default: 'resolved_date',
      readonly: true,
    },
    {
      name: 'Description',
      key: 'description',
      default: 'description',
      readonly: true,
    },
    {
      name: 'Resolution',
      key: 'resolution',
      default: 'resolution',
      readonly: true,
    },
    {
      name: 'Root_cause',
      key: 'root_cause',
      default: 'root_cause',
      readonly: true,
    },
    {
      name: 'Title',
      key: 'title',
      default: 'title',
      readonly: true,
    },
    {
      name: 'Status',
      key: 'status',
      default: 'status',
      readonly: true,
    },
    {
      name: 'Priority',
      key: 'priority',
      default: 'priority',
      readonly: true,
    },
    {
      name: 'Severity',
      key: 'severity',
      default: 'severity',
      readonly: true,
    },
    {
      name: 'Category',
      key: 'category',
      default: 'category',
      readonly: true,
    },
    {
      name: 'SLA',
      key: 'SLA',
      readonly: true,
      required: false,
    },
    {
      name: 'Infra_system',
      key: 'infra_system',
      default: 'infra_system',
      readonly: true,
    },
  ],
  testcase: [
    { name: 'ID', key: 'id', default: 'Testcase_id', readonly: true },
    {
      name: 'Issue Type',
      key: 'issue_type',
      default: 'issue_type',
      readonly: true,
    },
    {
      name: 'Created Date',
      key: 'created_date',
      default: 'created_date',
      readonly: true,
    },
    {
      name: 'Description',
      key: 'description',
      default: 'description',
      readonly: true,
    },
    {
      name: 'Title',
      key: 'title',
      default: 'title',
      readonly: true,
    },
    {
      name: 'Status',
      key: 'status',
      default: 'status',
      readonly: true,
    },
    {
      name: 'Priority',
      key: 'priority',
      default: 'priority',
      readonly: true,
    },
    {
      name: 'Severity',
      key: 'severity',
      default: 'severity',
      readonly: true,
    },
    {
      name: 'Category',
      key: 'category',
      default: 'category',
      readonly: true,
    },
  ],
  defect: [
    { name: 'ID', key: 'id', default: 'Defect_Id', readonly: true },
    {
      name: 'Issue Type',
      key: 'issue_type',
      default: 'issue_type',
      readonly: true,
    },
    {
      name: 'Application',
      key: 'application',
      default: 'application',
      readonly: true,
    },
    {
      name: 'Created Date',
      key: 'created_date',
      default: 'created_date',
      readonly: true,
    },
    {
      name: 'Resolved Date',
      key: 'resolved_date',
      default: 'resolved_date',
      readonly: true,
    },
    {
      name: 'Description',
      key: 'description',
      default: 'description',
      readonly: true,
    },
    {
      name: 'Resolution',
      key: 'resolution',
      default: 'resolution',
      readonly: true,
    },
    {
      name: 'Root_cause',
      key: 'root_cause',
      default: 'root_cause',
      readonly: true,
    },
    {
      name: 'Title',
      key: 'title',
      default: 'title',
      readonly: true,
    },
    {
      name: 'Status',
      key: 'status',
      default: 'status',
      readonly: true,
    },
    {
      name: 'Priority',
      key: 'priority',
      default: 'priority',
      readonly: true,
    },
    {
      name: 'Severity',
      key: 'severity',
      default: 'severity',
      readonly: true,
    },
    {
      name: 'Category',
      key: 'category',
      default: 'category',
      readonly: true,
    },
  ],
};

export const STATIC_USE_CASES_KEY = {
  incident: {
    TOP_10_ISSUES: 'top_10_issues',
    TOP_10_APPLICATIONS: 'top_10_applications',
    TOP_10_INFRASTRUCTURE_SYSTEMS: 'top_10_infrastructure_systems',
    TOP_10_RESOLUTION: 'Top 10 Resolutions',
    TOP_10_ROOT_CASES: 'Top 10 Root Causes',
    AI_INFERENCE: 'AI Inferences',
    POTENTIAL_AUTOMATION: 'Potential automation',
  },
  defect: {
    TOP_10_DEFECT: 'Top 10 Defect',
    TOP_10_FEATURES_EPICS_IMPACTED: 'Top 10 Features/Epics Impacted',
    TOP_10_RESOLUTIONS: 'Top 10 Resolutions',
    TOP_10_ROOT_CAUSES: 'Top 10 Root Causes',
    AI_INFERENCES: 'AI Inferences',
    POTENTIAL_REGRESSION_SCENARIOS: 'Potential regression scenarios',
  },
  testcase: {
    TESTCASE_HOTSPOTS: 'Testcase hotspots',
    TESTCASE_IMPACTED: 'Testcase Impacted',
    TESTCASE_PRIORITIZATION: 'Testcase prioritization',
    POTENTIAL_REGRESSION_TESTSUITE: 'Potential regression testsuite',
    POTENTIAL_AUTOMATION: 'Potential automation',
  },
} as const;

const mapper = (items: { description: string; json: object }[]) =>
  items.reduce<Record<string, IUseCase>>((acc, item) => {
    acc[item.description] = {
      ...item,
      json: JSON.stringify(item.json, null, 2),
      id: crypto.randomUUID(),
      source: 'static',
      persistence: 'local',
    };
    return acc;
  }, {});

export const STATIC_USE_CASES: Record<TEntity, Record<string, IUseCase>> = {
  incident: mapper([
    {
      description: STATIC_USE_CASES_KEY.incident.TOP_10_ISSUES,
      json: {
        agent_execution: {
          top_10_issues: {
            summary:
              'Top 10 issues reported from 2000-01-01 to 2026-04-16 based on incident_ticket_index1. Incident details and counts are aggregated by issue_type field.',
            top_issues: [
              {
                incident_count: 42,
                issue_type: 'incident',
                key_insights:
                  'The majority of incidents relate to ITSM operational events—encompassing network, password, hardware, and software failures—as captured in IT support and infrastructure environments.',
                matching_incidents: [
                  {
                    category: 'Network Issue',
                    date: '2025-12-04T13:00:00',
                    description:
                      'All workstations on the 3rd floor of Building v***@**  has A lost network connectivity at approximately 9:15 AM. Users cannot access email, shared drives, or  internet. Approximately 45 employees affected. Business operations severely impacted. Network switches appear to have power but no link lights showing on ports.',
                    incident_id: 'TKT-1001',
                    priority: 'Critical',
                    severity: 'Critical',
                    state: 'Resolved',
                    title:
                      'Complete loss of network v***@**.com connectivity in Building A - 3rd Floor',
                  },
                ],
                rank: 1,
                total_downtime_minutes: 62233,
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.incident.TOP_10_APPLICATIONS,
      json: {
        agent_execution: {
          top_10_applications: {
            date_range_applied: '2000-01-01 to 2026-04-16',
            incident_filter_applied: 'full set',
            summary:
              "Top 10 applications impacted from 2000-01-01 to 2026-04-16 in index 'incident_ticket_index1'. Analysis based on all incidents with the 'Application' field present in OpenSearch records.",
            top_applications: [
              {
                application: 'Identity & Access Management',
                incident_count: 8,
                key_insights:
                  'Identity & Access Management had the highest number of incidents involving account lockouts, password reset issues, and access management, indicating persistent authentication and access challenges.',
                matching_incidents: [
                  {
                    category: 'Password Reset',
                    created: '2025-12-16T11:30:00+00:00',
                    date: '2025-12-16',
                    incident_id: 'TKT-1004',
                    priority: 'Low',
                    severity: 'Low',
                    state: 'Resolved',
                    title:
                      'Unable to login - forgot password after returning ssn 078 05 1120 from vacation',
                  },
                ],
                rank: 1,
                total_downtime_minutes: 0,
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.incident.TOP_10_INFRASTRUCTURE_SYSTEMS,
      json: {
        agent_execution: {
          top_10_infrastructure_systems: {
            date_range_applied: '2000-01-01 to 2026-04-16',
            summary:
              'Top 10 infrastructure systems impacted from 2000-01-01 to 2026-04-16, based on incidents in incident_ticket_index1.',
            top_infrastructure_systems: [
              {
                incident_count: 4,
                infra_system: 'Printer Hardware (Paper Jam)',
                key_insights:
                  'Recurring paper jam issues affecting multiple departments. Maintenance and configuration reviews required.',
                matching_incidents: [
                  {
                    category: 'Printer Issue',
                    created: '2025-12-31T06:15:00+00:00',
                    date: '2025-12-31',
                    incident_id: 'TKT-1084',
                    priority: 'Critical',
                    severity: 'Critical',
                    state: 'On Hold',
                    title: 'Printer Dell Latitude 5420 paper jam in tray 11',
                  },
                ],
                rank: 1,
                total_downtime_minutes: 0,
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.incident.TOP_10_RESOLUTION,
      json: {
        agent_execution: {
          'Top 10 Resolutions': {
            date_range_applied: '2000-01-01 to 2026-03-30',
            summary:
              'Top 10 Resolutions from 2000-01-01 to 2026-03-30 in abc_incident index based on incident records.',
            top_resolutions: [
              {
                average_resolution_time_minutes: 3,
                incident_count: 209,
                key_insights:
                  'Frequent need for password resets, often resolved by verifying EmployeeID and using Fischer, highlights opportunities to streamline or automate this process.',
                matching_incidents: [
                  {
                    category: 'DT',
                    comment:
                      'Outlook set to "Hide" when minimized. Remove "Hide" option. Close all open Outlook Windows and re-open. Working like user wants it to.',
                    date: '2024-01-17T02:03:00+00:00',
                    impact: 'Low',
                    incident_id: 'INC0306113',
                    matchPercentage: '100%',
                    priority: '5 - Planning',
                    serviceType: '',
                    severity: '5 - Planning',
                    title: 'Outlook not functioning as normal',
                  },
                ],
                rank: 1,
                resolution: 'User needs network password reset.',
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.incident.TOP_10_ROOT_CASES,
      json: {
        agent_execution: {
          'Top 10 Root Causes': {
            date_range_applied: '2000-01-01 to 2026-04-16',
            summary:
              'Most common root causes among incident_ticket_index1 records from 2000-01-01 to 2026-04-16, grouped by recurring resolution descriptions and root causes where available.',
            top_root_causes: [
              {
                incident_count: 19,
                key_insights:
                  'Recurring application errors (SAP, Salesforce, Workday, Oracle, Boomi integration, database/report issues) due to misconfigurations, connection timeouts, permission/policy changes, or code issues. Multiple cases impacting multiple users/departments with business process disruption.',
                matching_incidents: [
                  {
                    category: 'Application Error',
                    created: '2025-12-24T22:00:00',
                    date: '2025-12-24',
                    incident_id: 'TKT-1024',
                    priority: 'Critical',
                    severity: 'Critical',
                    state: 'Resolved',
                    title:
                      "Salesforce - Unable to create opportunities, error 'UNABLE_TO_LOCK_ROW'",
                  },
                ],
                rank: 1,
                root_cause:
                  'Application Error / System Misconfiguration / Integration Failure',
                total_downtime_minutes: 0,
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.incident.AI_INFERENCE,
      json: {
        agent_execution: {
          'AI Inferences': {
            ai_inferences: [
              {
                description:
                  'A significant majority of incidents concern password resets, account lockouts, and credential synchronization for AD, JD Edwards, SAP, UltiPro, and VPN systems, often resulting in repeated interventions for the same users and devices.',
                impact:
                  '72–80% reduction in L1/L2 password reset workloads possible (high effort/high savings)',
                severity: 'HIGH',
                title: 'Identity/Access Issues Dominate',
              },
            ],
            date_range_applied: '2000-01-01 to 2026-03-30',
            incident_filter_applied: 'full set',
            summary:
              'AI inferences from abc_incident index for period 2000-01-01 to 2026-03-30, full data set. Findings include identity/access dominance, VPN/infra issues, email security trends, endpoint device failures, and automation opportunities.',
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.incident.POTENTIAL_AUTOMATION,
      json: {
        agent_execution: {
          'Potential automation': {
            automation_use_cases: [
              {
                automation_title: 'Automated Password Reset Workflow',
                description:
                  'Implement a self-service password reset tool for Active Directory and application accounts (e.g., JD Edwards, SAP, Outlook) to automate the password recovery and reset process.',
                incident_count: 392,
                potential_impact:
                  'Reduce 60-70% of password reset/helpdesk tickets and accelerate user account recovery.',
                rank: 1,
              },
            ],
            date_range_applied: '2000-01-01 to 2026-03-30',
            incident_filter_applied: 'full set',
            summary:
              "Potential automation opportunities identified from incident records in index 'abc_incident' for the period 2000-01-01 to 2026-03-30 based on recurring incident and resolution patterns.",
          },
        },
      },
    },
  ]),
  defect: mapper([
    {
      description: STATIC_USE_CASES_KEY.defect.TOP_10_DEFECT,
      json: {
        agent_execution: {
          'Top 10 Defect': {
            date_range_applied: '2000-01-01 to 2026-04-15',
            defect_filter_applied: 'full set',
            summary:
              "Top 10 defect-prone categories from 2000-01-01 to 2026-04-15 in index 'jira_defect_data' (filter: full set, 75 total defects)",
            top_areas: [
              {
                area: 'Market Place',
                defect_count: 34,
                key_insights:
                  'The Market Place area is the most defect-prone, with recurring issues in agent management, UI, and workflow integrations.',
                matching_defects: [
                  {
                    category: 'KG Graph is not displayed for sub subscription',
                    created: '17/Mar/26 6:28 PM',
                    defect_id: 'KKR-171',
                    priority: 'High',
                    severity: 'High',
                    state: 'Done',
                    title: 'KG Graph is not displayed for sub subscription',
                  },
                ],
                rank: 1,
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.defect.TOP_10_FEATURES_EPICS_IMPACTED,
      json: {
        agent_execution: {
          'Top 10 Features/Epics Impacted': {
            date_range_applied: '2000-01-01 to 2026-04-15',
            defect_filter_applied: 'full set',
            summary:
              "Top impacted features and epics from 2000-01-01 to 2026-04-15 based on the full set of defects in 'jira_defect_data'. Date range filter applied.",
            top_impacted_areas: [
              {
                defect_count: 34,
                feature_or_epic: 'Market Place',
                key_insights:
                  'Market Place epic has the highest volume, linked to recurring agent, workflow, and UI defects.',
                matching_defects: [
                  {
                    category: 'KG Graph is not displayed for sub subscription',
                    created: '17/Mar/26 6:28 PM',
                    defect_id: 'KKR-171',
                    priority: 'High',
                    severity: 'High',
                    state: 'Done',
                    title: 'KG Graph is not displayed for sub subscription',
                  },
                ],
                rank: 1,
                type: 'epic',
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.defect.TOP_10_RESOLUTIONS,
      json: {
        agent_execution: {
          'Top 10 Resolutions': {
            date_range_applied: '2000-01-01 to 2026-04-15',
            summary:
              "Top 10 most common resolutions for defects in index 'jira_defect_data' from 2000-01-01 to 2026-04-15 based on Done status and available resolution patterns.",
            top_resolutions: [
              {
                average_resolution_time_days: 18,
                defect_count: 18,
                key_insights:
                  'Front-end inconsistencies, length issues, and missing fields are quickly addressed, typically within 3-25 days.',
                matching_defects: [
                  {
                    category: 'Insight Page: UI & Functionality Issues',
                    created: '23/Jan/26 12:06 PM',
                    defect_id: 'KKR-115',
                    impact:
                      'Resolved visual overflow and browser compatibility.',
                    priority: 'Medium',
                    severity: 'Medium',
                    title: 'Insight Page: UI & Functionality Issues',
                  },
                ],
                rank: 1,
                resolution:
                  'UI/UX Bug Fixes Applied (input fields, output formatting, validation)',
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.defect.TOP_10_ROOT_CAUSES,
      json: {
        agent_execution: {
          'Top 10 Root Causes': {
            date_range_applied: '2000-01-01 to 2026-04-15',
            summary:
              'Top 10 root causes for defects from 2000-01-01 to 2026-04-15 (all available records from jira_defect_data analyzed using category/title/description patterns due to absence of explicit root_cause field)',
            top_root_causes: [
              {
                defect_count: 16,
                key_insights:
                  'Frequent issues with trace details, logs, or run/output information missing or incomplete, especially for agent and workflow executions.',
                matching_defects: [
                  {
                    category:
                      'Agent Logs: Run and log tab details are blank for agent executed from sub subscription',
                    created: '09/Mar/26 6:42 PM',
                    defect_id: 'KKR-141',
                    priority: 'High',
                    severity: 'High',
                    state: 'Done',
                    title:
                      'Agent Logs: Run and log tab details are blank for agent executed from sub subscription',
                  },
                ],
                rank: 1,
                root_cause:
                  'Log/Trace Details Missing or Not Displayed Properly',
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.defect.AI_INFERENCES,
      json: {
        agent_execution: {
          'AI Inferences': {
            ai_inferences: [
              {
                description:
                  'A significant portion of defects relate to missing, incomplete, or incorrect workflow and log trace details (trace IDs, agent run logs, document field data, cluster list updates). This creates debugging challenges and increases incident MTTR.',
                impact:
                  '52% of analyzed defects relate to workflow/log UI or trace gaps (high impact)',
                severity: 'HIGH',
                title: 'Recurring Workflow and Logging Trace Issues',
              },
            ],
            date_range_applied: '2000-01-01 to 2026-04-15',
            defect_filter_applied: 'full set',
            summary:
              "AI inferences for all defects in 'jira_defect_data' from 2000-01-01 to 2026-04-15. Sample size: 75 defects. Data shows patterns in recurring UI, workflow, logging and subscription issues that impact end-user experience and product stability.",
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.defect.POTENTIAL_REGRESSION_SCENARIOS,
      json: {},
    },
  ]),
  testcase: mapper([
    {
      description: STATIC_USE_CASES_KEY.testcase.TESTCASE_HOTSPOTS,
      json: {
        agent_execution: {
          'Testcase hotspots': {
            date_range_applied: '2000-01-01 to 2026-04-07',
            summary:
              'Test case hotspots from 2000-01-01 to 2026-04-07 (full date range applied, 100 records from kyc_testcase_data index). Grouped by category, ranked by total failure_count.',
            top_hotspots: [
              {
                failure_rate_percentage: 1.7,
                hotspot_area: 'UI',
                key_insights:
                  'UI category has most test cases and highest aggregated failure count, indicating more UI-related usability and visual regression checks are tested and sometimes fail.',
                matching_test_cases: [
                  {
                    execution_count: 30,
                    failure_count: 3,
                    priority: 'Medium',
                    status: 'Passed',
                    test_case_id: 'TC_011',
                    title: 'Verify responsive design mobile view',
                  },
                ],
                rank: 1,
                test_case_count: 20,
                total_failure_count: 11,
              },
            ],
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.testcase.TESTCASE_IMPACTED,
      json: {
        agent_execution: {
          'Testcase Impacted': {
            date_range_applied: '2000-01-01 to 2026-04-07',
            filter_applied: 'full set',
            impacted_test_cases: [
              {
                epic: 'Making KYC Simple and Friendly',
                execution_count: 19,
                failure_count: 4,
                feature: 'Non-Functional Requirements',
                key_insights:
                  'Highest failure count among all test cases in the period. Failed test on print CSS for form functionality; stability and reliability risks present.',
                last_executed: '2026-02-20T00:00:00',
                priority: 'Low',
                rank: 1,
                status: 'Failed',
                test_case_id: 'TC_091',
                title: 'Print form functionality check',
                use_case: 'Responsive Design',
              },
            ],
            summary:
              "Impacted test cases from 2000-01-01 to 2026-04-07 for index 'kyc_testcase_data'. All test cases were filtered using the 'created' and 'last_executed' fields to fall within this date range. Full set used as no specific impacted feature/epic/use_case was given.",
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.testcase.TESTCASE_PRIORITIZATION,
      json: {
        agent_execution: {
          'Testcase prioritization': {
            date_range_applied: '2000-01-01 to 2026-04-07',
            filter_applied: 'full set',
            prioritized_test_cases: [
              {
                business_criticality_score: 70,
                epic: 'Making KYC Simple and Friendly',
                execution_count: 53,
                failure_count: 4,
                failure_rate_percentage: 7.5,
                feature: 'Comprehensive Form Validation',
                impact_explanation:
                  "Targets core Form Submission path in 'Comprehensive Form Validation' feature, critical to user completion flow.",
                impact_relevance_score: 100,
                overall_priority_score: 72,
                prioritization_reason: 'Highest failure count in the dataset.',
                priority: 'Medium',
                rank: 1,
                risk_score: 64,
                status: 'Failed',
                test_case_id: 'TC_050',
                title: 'Form submission network timeout',
                use_case: 'Form Submission',
              },
            ],
            summary:
              "Test case prioritization for all features/epics/use_cases from 2000-01-01 to 2026-04-07 in index 'kyc_testcase_data'. Ranked by failure_count, execution_count, and priority.",
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.testcase.POTENTIAL_REGRESSION_TESTSUITE,
      json: {
        agent_execution: {
          'Potential regression testsuite': {
            coverage_distribution: {
              by_application: {
                'KYC Plus': 100,
              },
              by_feature: {
                'Comprehensive Form Validation': 19,
                'Document Verification': 5,
                'India Regional Compliance': 13,
                'Non-Functional Requirements': 8,
                'Personal Information Collection': 15,
                'Secure User Authentication': 15,
                'Smart Document Processing': 11,
                'US Regional Compliance': 13,
              },
              risk_levels: {
                high: 24,
                low: 28,
                medium: 48,
              },
              total_tests_selected: 100,
            },
            date_range_applied: '2000-01-01 to 2026-04-07',
            regression_strategy: {
              exclusions: [
                'Deprecated/Obsolete statuses (none present)',
                'Blocked or removed flows (none present)',
              ],
              selection_criteria: [
                'High priority first',
                'Business-critical user flows from features/epics',
                'High execution frequency (top quartiles prioritized)',
                'Stability threshold: <= 20% recent failure rate',
              ],
            },
            regression_suite: [
              {
                application: 'KYC Plus',
                business_criticality_score: 100,
                epic: 'Making KYC Simple and Friendly',
                execution_history: {
                  execution_count: 68,
                  failure_count: 0,
                  failure_rate_percentage: 0,
                  last_executed: '2026-02-27T00:00:00',
                },
                feature: 'Comprehensive Form Validation',
                justification:
                  'High priority, maximum execution count, covers all critical regression flows, no failures in history, core end-to-end coverage.',
                priority: 'High',
                rank: 1,
                recommended_execution_frequency: 'Daily',
                regression_candidate_score: 82,
                status: 'Passed',
                technical_risk_score: 55,
                test_case_id: 'TC_100',
                title: 'Overall regression full US + India flow',
                use_case: 'Form Submission',
              },
            ],
            summary:
              'Potential regression suite built from kyc_testcase_data between 2000-01-01 and 2026-04-07. High and medium priority, core and frequently executed test cases included, targeting <= 20% recent failure rate. Obsolete/Deprecated/Removed statuses not present.',
          },
        },
      },
    },
    {
      description: STATIC_USE_CASES_KEY.testcase.POTENTIAL_AUTOMATION,
      json: {
        agent_execution: {
          'Potential automation': {
            automation_use_cases: [
              {
                application: 'KYC Plus',
                automation_feasibility: {
                  overall_automation_score: 100,
                  repeatability_score: 100,
                  stability_score: 100,
                  technical_feasibility_score: 100,
                },
                automation_title:
                  'Automate end-to-end US and India KYC full flow',
                category: 'E2E',
                description:
                  'This E2E test covers all critical KYC user flows across both US and India; ideal for stable and repeatable regression automation due to high execution and zero recent failures.',
                epic: 'Making KYC Simple and Friendly',
                estimated_automation_effort: 'Low',
                execution_profile: {
                  execution_count: 68,
                  failure_count: 0,
                  failure_rate_percentage: 0,
                  last_executed: '2026-02-27T00:00:00',
                },
                feature: 'Comprehensive Form Validation',
                potential_impact:
                  'Covers all business critical paths, enables fast full KYC regression on every release',
                priority: 'High',
                rank: 1,
                roi_estimate: 'High ROI',
                status: 'Passed',
                test_case_id: 'TC_100',
                title: 'Overall regression full US + India flow',
                use_case: 'Form Submission',
              },
            ],
            date_range_applied: '2000-01-01 to 2026-04-07',
            summary:
              "Potential automation use cases from 2000-01-01 to 2026-04-07 for index 'kyc_testcase_data'; filter applied to all test cases in this date range.",
            test_case_filter_applied: 'full set',
          },
        },
      },
    },
  ]),
};

export const STATIC_USE_CASE_LABEL_MAPPING: Record<string, string> = {
  'Potential automation': 'Potential Automation Use Cases',
  top_10_applications: 'Top 10 Applications Impacted',
  top_10_infrastructure_systems: 'Top 10 Infra Impacted',
  top_10_issues: 'Top 10 Issues Reported',

  'Top 10 Defect': 'Defect Hotspots',
  'Top 10 Features/Epics Impacted': 'Top 10 Features and Epics Impacted',

  'Potential regression testsuite': 'Potential Regression Test Suite',
  'Testcase Impacted': 'High Impacted Epics and Features',
  'Testcase hotspots': 'Testcase Hotspots',
  'Testcase prioritization': 'Impact Based Test Case Prioritization',
};
