import { ChartType, Plugin } from 'chart.js';

export interface ICenterTextPluginOptions {
  text?: string;
  subtext?: string;
  textFont?: string;
  subtextFont?: string;
}

export const CenterTextPlugin: Plugin<'doughnut', ICenterTextPluginOptions> = {
  id: 'centerText',
  afterDraw: function (chart, _args, options) {
    const {
      ctx,
      chartArea: { left, right, top, bottom },
    } = chart;

    if (!options.subtext && !options.text) return;

    // Calculate center position
    const centerX = (left + right) / 2;
    const centerY = (top + bottom) / 2;

    ctx.save();

    if (options.text) {
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = options.textFont || '500 34px Fira Sans';
      ctx.fillStyle = '#262E2B';
      ctx.fillText(options.text, centerX, centerY - 15);
    }

    if (options.subtext) {
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = options.subtextFont || '400 14px Fira Sans';
      ctx.fillStyle = '#262E2B';
      ctx.fillText(options.subtext, centerX, centerY + 15);
    }

    ctx.restore();
  },
};

declare module 'chart.js' {
  interface PluginOptionsByType<TType extends ChartType = ChartType> {
    centerText?: ICenterTextPluginOptions;
  }
}
