import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResponse, IAgent, ISearchIndex } from '../types';
import { abort } from '../utils';

@Injectable({
  providedIn: 'root',
})
export class SemarketplaceService {
  constructor(private _http: HttpClient) {}
  //#region MarkerPlace/Agent-Services
  onboardInternalAgent(params: any) {
    return this._http.post<ApiResponse<null>>(`/AddAgentDetails`, params);
  }

  onboardExternalAgent(params: any) {
    return this._http.post<ApiResponse<null>>(`/AddExternalAgent`, params);
  }
  getAgentDetails() {
    return this._http.post<ApiResponse<IAgent[]>>(`/GetAllAgents`, null);
  }

  updateAgentDetails(payload: any) {
    return this._http.put<ApiResponse<null>>(
      `/UpdateAgentDetails/${payload.agent_id}`,
      payload,
    );
  }
  getAllDropdowns() {
    return this._http.get<
      ApiResponse<
        Record<
          | 'mcp_connectors'
          | 'ai_models'
          | 'roles'
          | 'agent_types'
          | 'agent_providers'
          | 'knowledge_store'
          | 'ai_foundations',
          { label: string; value: string }[]
        >
      >
    >(`/dropdowns/all`);
  }
  deleteAgent(agentId: string) {
    return this._http.post<ApiResponse<null>>(`/DeleteAgent/${agentId}`, null);
  }

  getAgentCounts() {
    return this._http.get<
      ApiResponse<{
        total_agents: number;
        active_agents: number;
        trending_agents: number;
      }>
    >(`/agentcounts`);
  }

  getProviderDetails(params: any) {
    return this._http.post<
      ApiResponse<{ provider_url: string; provider_key: string }>
    >(`/GetProviderDetails`, params);
  }
  //#endregion

  //#region MarkerPlace/Agency-Services
  getAgencyWithAgentsById(agencyId: string): Observable<any> {
    return this._http.get(`/GetAgencyWithAgents/${agencyId}`);
  }

  getAgencytype() {
    return this._http.get<ApiResponse<unknown[]>>(`/agencytypes`);
  }

  onboardAgencyWithAgents(params: any) {
    return this._http.post<
      ApiResponse<{
        agency_id: string;
        agency_type_counts: Record<string, number>;
      }>
    >(`/OnboardAgencyWithAgents`, params);
  }

  getAgencyWithAgents() {
    return this._http.get<ApiResponse<unknown[]>>(`/GetAgencyWithAgents`);
  }

  getTrendingAgencyStats() {
    return this._http.get<
      ApiResponse<{
        total_agencies: number;
        trending_agencies: number;
        filter_status: string;
        agencies: unknown[];
      }>
    >(`/agency/stats`);
  }

  getAllAgencies() {
    return this._http.get<ApiResponse<IAgent[]>>(`/GetTaskAgentsDetails`);
  }

  deleteAgencyDetails(agencyId: any): Observable<any> {
    return this._http.delete<any>(`/DeleteAgencyDetails/${agencyId}`);
  }

  GetAgentAndOrder2Agents(params: any) {
    return this._http.post<
      ApiResponse<{ main_agent: unknown; order_2_agents: unknown[] }>
    >(`/GetAgentAndOrder2Agents`, params);
  }

  getAgentsByAgency(params: any) {
    return this._http.post<
      ApiResponse<{ mappings: unknown[]; agents: IAgent[] }>
    >(`/AgencyMappings`, params);
  }
  getUpdatedExternalData(params: any) {
    return this._http.post<ApiResponse<boolean>>(`/LatestAgentDetails`, params);
  }
  //#endregion

  //#region KnowledgeStore-Services
  getKnowledgeStoreCounts() {
    return this._http.get<ApiResponse<{ total_knowlegeGraph: number }>>(
      `/getKnowledgestoreDetailsCounts`,
    );
  }

  getKnowledgeStoreDetails() {
    return this._http.post<ApiResponse<{ _id: string }[]>>(
      `/GetKnowledgeStoreDetails`,
      null,
    );
  }

  getKnowledgeStoreDocDetails(rag_id: any) {
    return this._http.post<ApiResponse<string[]>>(
      `/GetKnowledgeStoreDocDetails/${rag_id}`,
      null,
    );
  }

  getMCPConnectorsDetails(signal: AbortSignal) {
    return this._http
      .post<{ indexes: ISearchIndex[] }>(`/insights/opensearchindex`, null)
      .pipe(abort(signal));
  }

  getColumnsForExcelUpload(params: FormData) {
    return this._http.post<{ columns: string[] }>(
      `/insights/extractcolumn`,
      params,
    );
  }

  getSheetsForExcelUpload(params: any) {
    return this._http.post<{ sheet_names: string[]; status: string }>(
      `/insights/extractsheet`,
      params,
    );
  }

  ingestandUpdateDocMcp(params: any) {
    return this._http.post<ApiResponse<null>>(
      `/insights/ingestandupdatedoc`,
      params,
    );
  }

  getMCPDataForIndex(params: { index_id: string }) {
    return this._http.post<{ data: ISearchIndex; status: string }>(
      `/insights/indexbyid`,
      params,
    );
  }

  syncMCPToOpenSearch(params: { index_id: string; index_name: string }) {
    return this._http.post<{ status: string; message: string }>(
      `/insights/opensearchingestandupdate`,
      params,
    );
  }

  deleteMCPConnector(params: { index_id: string; index_name: string }) {
    return this._http.post<{ status: string; message: string }>(
      `/insights/deleteindex`,
      params,
    );
  }

  getMCPStatistics() {
    return this._http.get<{
      data: {
        connector_count: number;
        mcp_connector_count: Record<string, number>;
        mcp_count: number;
        total_entity_count: number;
        mcp_entity_count: Record<string, number>;
      };
      message: string;
      success: boolean;
    }>(`/getMCPStatistics`);
  }
  getKGStatistics() {
    return this._http.get<
      ApiResponse<{
        agencies_by_team: Record<string, number>;
        total_agencies: number;
      }>
    >(`/GetKnowledgeStoreStatistics`);
  }

  getAgencyStatistics() {
    return this._http.get<
      ApiResponse<{
        agencies_by_team: Record<string, number>;
        total_agencies: number;
      }>
    >(`/AgencyStatistics`);
  }

  getJiraProjects(
    params: {
      username: string;
      api_token: string;
      connector_url: string;
    },
    signal: AbortSignal,
  ) {
    return this._http
      .post<{
        project_keys: string[];
        status: string;
      }>(`/insights/jiraprojectkey`, params)
      .pipe(abort(signal));
  }

  getTeamDynamixApplications(
    params: {
      username: string;
      password: string;
      connector_url: string;
    },
    signal: AbortSignal,
  ) {
    return this._http
      .post<{
        app_ids: string[];
        message: string;
        status: string;
      }>(`/insights/fetchappid`, params)
      .pipe(abort(signal));
  }

  //#endregion
}
